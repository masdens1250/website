import {
  users, type User, type InsertUser,
  categories, type Category, type InsertCategory,
  products, type Product, type InsertProduct,
  retailers, type Retailer, type InsertRetailer,
  productPrices, type ProductPrice, type InsertProductPrice,
  comparisons, type Comparison, type InsertComparison,
  comparisonProducts, type ComparisonProduct, type InsertComparisonProduct,
  reviews, type Review, type InsertReview,
  reviewCriteria, type ReviewCriteria, type InsertReviewCriteria
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Categories
  getCategories(): Promise<Category[]>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  
  // Products
  getProducts(): Promise<Product[]>;
  getProductById(id: number): Promise<Product | undefined>;
  getProductBySlug(slug: string): Promise<Product | undefined>;
  getProductsByCategory(categoryId: number): Promise<Product[]>;
  
  // Retailers
  getRetailers(): Promise<Retailer[]>;
  
  // Product Prices
  getProductPricesByProductId(productId: number): Promise<ProductPrice[]>;
  
  // Comparisons
  getComparisons(): Promise<Comparison[]>;
  getComparisonBySlug(slug: string): Promise<Comparison | undefined>;
  getComparisonsByCategory(categoryId: number): Promise<Comparison[]>;
  
  // Comparison Products
  getComparisonProductsByComparisonId(comparisonId: number): Promise<ComparisonProduct[]>;
  
  // Reviews
  getReviews(): Promise<Review[]>;
  getReviewsByProductId(productId: number): Promise<Review[]>;
  
  // Review Criteria
  getReviewCriteriaByReviewId(reviewId: number): Promise<ReviewCriteria[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private categories: Map<number, Category>;
  private products: Map<number, Product>;
  private retailers: Map<number, Retailer>;
  private productPrices: Map<number, ProductPrice>;
  private comparisons: Map<number, Comparison>;
  private comparisonProducts: Map<number, ComparisonProduct>;
  private reviews: Map<number, Review>;
  private reviewCriteria: Map<number, ReviewCriteria>;
  
  currentUserId: number;
  currentCategoryId: number;
  currentProductId: number;
  currentRetailerId: number;
  currentProductPriceId: number;
  currentComparisonId: number;
  currentComparisonProductId: number;
  currentReviewId: number;
  currentReviewCriteriaId: number;

  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.products = new Map();
    this.retailers = new Map();
    this.productPrices = new Map();
    this.comparisons = new Map();
    this.comparisonProducts = new Map();
    this.reviews = new Map();
    this.reviewCriteria = new Map();
    
    this.currentUserId = 1;
    this.currentCategoryId = 1;
    this.currentProductId = 1;
    this.currentRetailerId = 1;
    this.currentProductPriceId = 1;
    this.currentComparisonId = 1;
    this.currentComparisonProductId = 1;
    this.currentReviewId = 1;
    this.currentReviewCriteriaId = 1;
    
    // Initialize with sample data
    this.initializeData();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Category methods
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }
  
  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    return Array.from(this.categories.values()).find(
      (category) => category.slug === slug,
    );
  }
  
  // Product methods
  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }
  
  async getProductById(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }
  
  async getProductBySlug(slug: string): Promise<Product | undefined> {
    return Array.from(this.products.values()).find(
      (product) => product.slug === slug,
    );
  }
  
  async getProductsByCategory(categoryId: number): Promise<Product[]> {
    return Array.from(this.products.values()).filter(
      (product) => product.categoryId === categoryId,
    );
  }
  
  // Retailer methods
  async getRetailers(): Promise<Retailer[]> {
    return Array.from(this.retailers.values());
  }
  
  // Product Price methods
  async getProductPricesByProductId(productId: number): Promise<ProductPrice[]> {
    return Array.from(this.productPrices.values()).filter(
      (productPrice) => productPrice.productId === productId,
    );
  }
  
  // Comparison methods
  async getComparisons(): Promise<Comparison[]> {
    return Array.from(this.comparisons.values());
  }
  
  async getComparisonBySlug(slug: string): Promise<Comparison | undefined> {
    return Array.from(this.comparisons.values()).find(
      (comparison) => comparison.slug === slug,
    );
  }
  
  async getComparisonsByCategory(categoryId: number): Promise<Comparison[]> {
    return Array.from(this.comparisons.values()).filter(
      (comparison) => comparison.categoryId === categoryId,
    );
  }
  
  // Comparison Product methods
  async getComparisonProductsByComparisonId(comparisonId: number): Promise<ComparisonProduct[]> {
    return Array.from(this.comparisonProducts.values()).filter(
      (comparisonProduct) => comparisonProduct.comparisonId === comparisonId,
    ).sort((a, b) => a.order - b.order);
  }
  
  // Review methods
  async getReviews(): Promise<Review[]> {
    return Array.from(this.reviews.values());
  }
  
  async getReviewsByProductId(productId: number): Promise<Review[]> {
    return Array.from(this.reviews.values()).filter(
      (review) => review.productId === productId,
    );
  }
  
  // Review Criteria methods
  async getReviewCriteriaByReviewId(reviewId: number): Promise<ReviewCriteria[]> {
    return Array.from(this.reviewCriteria.values()).filter(
      (reviewCriteria) => reviewCriteria.reviewId === reviewId,
    );
  }
  
  private initializeData() {
    // Add categories
    const categoryData: InsertCategory[] = [
      { name: "Gaming", slug: "gaming", icon: "fa-gamepad", colorClass: "blue" },
      { name: "Son & Vidéo", slug: "son-video", icon: "fa-headphones", colorClass: "purple" },
      { name: "Sport & Loisir", slug: "sport-loisir", icon: "fa-running", colorClass: "green" },
      { name: "Cuisine", slug: "cuisine", icon: "fa-utensils", colorClass: "yellow" },
      { name: "Maison & Entretien", slug: "maison-entretien", icon: "fa-home", colorClass: "red" },
      { name: "Tech", slug: "tech", icon: "fa-laptop", colorClass: "indigo" },
      { name: "Forme & Beauté", slug: "forme-beaute", icon: "fa-spa", colorClass: "pink" },
    ];
    
    categoryData.forEach(cat => {
      const id = this.currentCategoryId++;
      const category: Category = { ...cat, id };
      this.categories.set(id, category);
    });
    
    // Add retailers
    const retailerData: InsertRetailer[] = [
      { name: "Amazon", slug: "amazon", logoUrl: "https://upload.wikimedia.org/wikipedia/commons/4/4a/Amazon_icon.svg" },
      { name: "Cdiscount", slug: "cdiscount", logoUrl: "https://upload.wikimedia.org/wikipedia/en/e/e9/Cdiscount.png" },
      { name: "Fnac", slug: "fnac", logoUrl: "https://upload.wikimedia.org/wikipedia/commons/2/2e/Fnac_Logo.svg" },
      { name: "Rakuten", slug: "rakuten", logoUrl: "https://upload.wikimedia.org/wikipedia/commons/4/4c/Rakuten_Global_Brand_Logo.svg" },
    ];
    
    retailerData.forEach(ret => {
      const id = this.currentRetailerId++;
      const retailer: Retailer = { ...ret, id };
      this.retailers.set(id, retailer);
    });
    
    // Add products
    const productData: InsertProduct[] = [
      { 
        name: "Samsung Galaxy S23 Ultra", 
        slug: "samsung-galaxy-s23-ultra", 
        description: "L'ultime smartphone Samsung avec un S Pen intégré et un appareil photo de 108MP.",
        imageUrl: "https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800&q=80",
        categoryId: 6, // Tech
        price: 109900, // 1099.00€
        rating: 480, // 4.8/5
        specifications: JSON.stringify({
          screen: "6.8\" AMOLED",
          battery: "5000 mAh",
          camera: "108MP + 12MP + 10MP",
          processor: "Snapdragon 8 Gen 2",
          memory: "8GB/12GB",
          storage: "256GB/512GB/1TB"
        }),
        updatedAt: new Date()
      },
      { 
        name: "iPhone 14 Pro Max", 
        slug: "iphone-14-pro-max", 
        description: "Le dernier iPhone haut de gamme d'Apple avec Dynamic Island et un appareil photo de 48MP.",
        imageUrl: "https://images.unsplash.com/photo-1591337676887-a217a6970a8a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800&q=80",
        categoryId: 6, // Tech
        price: 122900, // 1229.00€
        rating: 470, // 4.7/5
        specifications: JSON.stringify({
          screen: "6.7\" Super Retina XDR",
          battery: "4323 mAh",
          camera: "48MP + 12MP + 12MP",
          processor: "A16 Bionic",
          memory: "6GB",
          storage: "128GB/256GB/512GB/1TB"
        }),
        updatedAt: new Date()
      },
      { 
        name: "Google Pixel 7 Pro", 
        slug: "google-pixel-7-pro", 
        description: "L'excellence photographique selon Google avec un écran lumineux et une grande autonomie.",
        imageUrl: "https://images.unsplash.com/photo-1598327105666-5b89351aff97?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800&q=80",
        categoryId: 6, // Tech
        price: 89900, // 899.00€
        rating: 460, // 4.6/5
        specifications: JSON.stringify({
          screen: "6.7\" LTPO OLED",
          battery: "5000 mAh",
          camera: "50MP + 12MP + 48MP",
          processor: "Google Tensor G2",
          memory: "12GB",
          storage: "128GB/256GB/512GB"
        }),
        updatedAt: new Date()
      },
      { 
        name: "Sony WH-1000XM5", 
        slug: "sony-wh-1000xm5", 
        description: "Le casque sans fil avec la meilleure réduction de bruit active du marché.",
        imageUrl: "https://images.unsplash.com/photo-1605464808606-b4471a789912?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800&q=80",
        categoryId: 2, // Son & Vidéo
        price: 34900, // 349.00€
        rating: 490, // 4.9/5
        specifications: JSON.stringify({
          type: "Circum-aural fermé",
          connectivity: "Bluetooth 5.2, Jack 3.5mm",
          battery: "30 heures avec ANC",
          weight: "250g",
          drivers: "30mm"
        }),
        updatedAt: new Date()
      },
      { 
        name: "Dyson V12 Detect Slim", 
        slug: "dyson-v12-detect-slim", 
        description: "Aspirateur sans fil avec détection laser de la poussière pour un nettoyage optimal.",
        imageUrl: "https://images.unsplash.com/photo-1558317374-067fb5f30001?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800&q=80",
        categoryId: 5, // Maison & Entretien
        price: 54900, // 549.00€
        rating: 450, // 4.5/5
        specifications: JSON.stringify({
          power: "150 AW",
          batteryLife: "60 minutes",
          dustCapacity: "0.35L",
          weight: "2.2kg",
          filters: "HEPA"
        }),
        updatedAt: new Date()
      },
      { 
        name: "Nintendo Switch OLED", 
        slug: "nintendo-switch-oled", 
        description: "La console hybride de Nintendo avec un écran OLED plus grand et plus lumineux.",
        imageUrl: "https://images.unsplash.com/photo-1617096200347-cb04ae810b1d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800&q=80",
        categoryId: 1, // Gaming
        price: 31900, // 319.00€
        rating: 470, // 4.7/5
        specifications: JSON.stringify({
          screen: "7\" OLED",
          storage: "64GB",
          battery: "4.5-9 heures",
          connectivity: "Wi-Fi, Bluetooth, USB-C",
          weight: "320g (console only)"
        }),
        updatedAt: new Date()
      }
    ];
    
    productData.forEach(prod => {
      const id = this.currentProductId++;
      const product: Product = { ...prod, id };
      this.products.set(id, product);
    });
    
    // Add product prices for each retailer
    const amazonId = 1;
    const cdiscountId = 2;
    const fnacId = 3;
    const rakutenId = 4;
    
    // Samsung Galaxy S23 Ultra prices
    this.addProductPrice(1, amazonId, 109900, false, 0, "https://www.amazon.fr/Samsung-Galaxy-Ultra-Smartphone-Android/");
    this.addProductPrice(1, cdiscountId, 114900, false, 0, "https://www.cdiscount.com/samsung-galaxy-s23-ultra");
    this.addProductPrice(1, fnacId, 112900, false, 0, "https://www.fnac.com/samsung-galaxy-s23-ultra");
    
    // iPhone 14 Pro Max prices
    this.addProductPrice(2, amazonId, 122900, false, 0, "https://www.amazon.fr/Apple-iPhone-14-Pro-Max");
    this.addProductPrice(2, cdiscountId, 124900, false, 0, "https://www.cdiscount.com/apple-iphone-14-pro-max");
    this.addProductPrice(2, fnacId, 123900, false, 0, "https://www.fnac.com/apple-iphone-14-pro-max");
    
    // Google Pixel 7 Pro prices
    this.addProductPrice(3, amazonId, 89900, true, 15, "https://www.amazon.fr/Google-Pixel-7-Pro");
    this.addProductPrice(3, cdiscountId, 92900, false, 0, "https://www.cdiscount.com/google-pixel-7-pro");
    this.addProductPrice(3, fnacId, 94900, false, 0, "https://www.fnac.com/google-pixel-7-pro");
    
    // Sony WH-1000XM5 prices
    this.addProductPrice(4, amazonId, 34900, false, 0, "https://www.amazon.fr/Sony-WH-1000XM5");
    this.addProductPrice(4, cdiscountId, 34900, false, 0, "https://www.cdiscount.com/sony-wh-1000xm5");
    this.addProductPrice(4, fnacId, 34900, false, 0, "https://www.fnac.com/sony-wh-1000xm5");
    
    // Dyson V12 Detect Slim prices
    this.addProductPrice(5, amazonId, 54900, false, 0, "https://www.amazon.fr/Dyson-V12-Detect-Slim");
    this.addProductPrice(5, cdiscountId, 54900, false, 0, "https://www.cdiscount.com/dyson-v12-detect-slim");
    this.addProductPrice(5, fnacId, 54900, false, 0, "https://www.fnac.com/dyson-v12-detect-slim");
    
    // Nintendo Switch OLED prices
    this.addProductPrice(6, amazonId, 31900, false, 0, "https://www.amazon.fr/Nintendo-Switch-OLED");
    this.addProductPrice(6, cdiscountId, 31900, false, 0, "https://www.cdiscount.com/nintendo-switch-oled");
    this.addProductPrice(6, fnacId, 31900, false, 0, "https://www.fnac.com/nintendo-switch-oled");
    
    // Add comparisons
    const comparisonData: InsertComparison[] = [
      {
        title: "Les meilleurs écouteurs sans fil",
        slug: "meilleurs-ecouteurs-sans-fil",
        description: "Nous avons testé les 10 écouteurs Bluetooth les plus populaires pour vous aider à faire le meilleur choix.",
        imageUrl: "https://images.unsplash.com/photo-1606318801954-d46d46d3360a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=450&q=80",
        categoryId: 2, // Son & Vidéo
        updatedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000) // 5 days ago
      },
      {
        title: "Top 5 des aspirateurs robots",
        slug: "top-5-aspirateurs-robots",
        description: "Découvrez notre sélection des meilleurs aspirateurs robots pour garder votre maison propre sans effort.",
        imageUrl: "https://images.unsplash.com/photo-1504707748692-419802cf939d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=450&q=80",
        categoryId: 5, // Maison & Entretien
        updatedAt: new Date(Date.now() - 13 * 24 * 60 * 60 * 1000) // 13 days ago
      },
      {
        title: "Comparatif des meilleurs laptops",
        slug: "comparatif-meilleurs-laptops",
        description: "Notre guide complet pour choisir l'ordinateur portable parfait selon vos besoins et votre budget.",
        imageUrl: "https://images.unsplash.com/photo-1593642632823-8f785ba67e45?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=450&q=80",
        categoryId: 6, // Tech
        updatedAt: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000) // 20 days ago
      },
      {
        title: "Smartphones haut de gamme",
        slug: "smartphones-haut-de-gamme",
        description: "Découvrez notre analyse détaillée des derniers smartphones premium du marché pour faire le meilleur choix selon vos besoins.",
        imageUrl: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=450&q=80",
        categoryId: 6, // Tech
        updatedAt: new Date()
      }
    ];
    
    comparisonData.forEach(comp => {
      const id = this.currentComparisonId++;
      const comparison: Comparison = { ...comp, id };
      this.comparisons.set(id, comparison);
    });
    
    // Add smartphone comparison products
    const phoneComparisonId = 4;
    this.addComparisonProduct(phoneComparisonId, 1, 1); // Samsung S23 Ultra
    this.addComparisonProduct(phoneComparisonId, 2, 2); // iPhone 14 Pro Max
    this.addComparisonProduct(phoneComparisonId, 3, 3); // Pixel 7 Pro
    
    // Add reviews
    this.addReview(
      4, // Sony WH-1000XM5
      "Thomas D.",
      "https://images.unsplash.com/photo-1600486913747-55e5470d6f40?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80&q=80",
      "Sony WH-1000XM5 - Le roi des casques sans fil",
      "J'ai testé ce casque pendant un mois et je suis bluffé par la qualité de la réduction de bruit. L'autonomie est excellente et le confort est au rendez-vous même après plusieurs heures d'utilisation.",
      500, // 5.0/5
      new Date(Date.now() - 2 * 24 * 60 * 60 * 1000) // 2 days ago
    );
    
    this.addReview(
      5, // Dyson V12
      "Julie M.",
      "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80&q=80",
      "Dyson V12 Detect Slim - Puissant mais bruyant",
      "J'ai craqué pour ce nouvel aspirateur Dyson et je ne suis pas déçue par son efficacité. La puissance d'aspiration est impressionnante et la détection laser des poussières est vraiment pratique. Seul bémol : le bruit assez important.",
      400, // 4.0/5
      new Date(Date.now() - 5 * 24 * 60 * 60 * 1000) // 5 days ago
    );
    
    this.addReview(
      6, // Nintendo Switch OLED
      "Marc L.",
      "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80&q=80",
      "Nintendo Switch OLED - Une belle évolution",
      "Après plusieurs années avec ma Switch classique, j'ai décidé de passer à la version OLED. La différence d'écran est impressionnante, surtout en mode portable. Les couleurs sont vives et le noir bien plus profond.",
      450, // 4.5/5
      new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) // 7 days ago
    );
    
    // Add review criteria
    // For Sony WH-1000XM5 review
    this.addReviewCriteria(1, "Autonomie", 500); // 5.0/5
    this.addReviewCriteria(1, "Qualité audio", 450); // 4.5/5
    
    // For Dyson V12 review
    this.addReviewCriteria(2, "Puissance", 500); // 5.0/5
    this.addReviewCriteria(2, "Bruit", 300); // 3.0/5
    
    // For Nintendo Switch OLED review
    this.addReviewCriteria(3, "Qualité d'écran", 500); // 5.0/5
    this.addReviewCriteria(3, "Rapport qualité/prix", 400); // 4.0/5
  }
  
  private addProductPrice(productId: number, retailerId: number, price: number, isPromotion: boolean, discountPercentage: number, affiliateUrl: string) {
    const id = this.currentProductPriceId++;
    const productPrice: ProductPrice = {
      id,
      productId,
      retailerId,
      price,
      isPromotion,
      discountPercentage: discountPercentage || null,
      affiliateUrl
    };
    this.productPrices.set(id, productPrice);
  }
  
  private addComparisonProduct(comparisonId: number, productId: number, order: number) {
    const id = this.currentComparisonProductId++;
    const comparisonProduct: ComparisonProduct = {
      id,
      comparisonId,
      productId,
      order
    };
    this.comparisonProducts.set(id, comparisonProduct);
  }
  
  private addReview(
    productId: number,
    authorName: string,
    authorAvatar: string,
    title: string,
    content: string,
    rating: number,
    createdAt: Date
  ) {
    const id = this.currentReviewId++;
    const review: Review = {
      id,
      productId,
      authorName,
      authorAvatar,
      title,
      content,
      rating,
      createdAt
    };
    this.reviews.set(id, review);
    return id;
  }
  
  private addReviewCriteria(reviewId: number, name: string, rating: number) {
    const id = this.currentReviewCriteriaId++;
    const criteria: ReviewCriteria = {
      id,
      reviewId,
      name,
      rating
    };
    this.reviewCriteria.set(id, criteria);
  }
}

export const storage = new MemStorage();
