import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes - prefix all routes with /api
  
  // Get all categories
  app.get("/api/categories", async (req, res) => {
    const categories = await storage.getCategories();
    res.json(categories);
  });
  
  // Get category by slug
  app.get("/api/categories/:slug", async (req, res) => {
    const { slug } = req.params;
    const category = await storage.getCategoryBySlug(slug);
    
    if (!category) {
      return res.status(404).json({ message: "Category not found" });
    }
    
    res.json(category);
  });
  
  // Get all products
  app.get("/api/products", async (req, res) => {
    const products = await storage.getProducts();
    res.json(products);
  });
  
  // Get product by slug
  app.get("/api/products/:slug", async (req, res) => {
    const { slug } = req.params;
    const product = await storage.getProductBySlug(slug);
    
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }
    
    res.json(product);
  });
  
  // Get products by category
  app.get("/api/categories/:categoryId/products", async (req, res) => {
    const categoryId = parseInt(req.params.categoryId);
    
    if (isNaN(categoryId)) {
      return res.status(400).json({ message: "Invalid category ID" });
    }
    
    const products = await storage.getProductsByCategory(categoryId);
    res.json(products);
  });
  
  // Get all retailers
  app.get("/api/retailers", async (req, res) => {
    const retailers = await storage.getRetailers();
    res.json(retailers);
  });
  
  // Get product prices by product ID
  app.get("/api/products/:productId/prices", async (req, res) => {
    const productId = parseInt(req.params.productId);
    
    if (isNaN(productId)) {
      return res.status(400).json({ message: "Invalid product ID" });
    }
    
    const prices = await storage.getProductPricesByProductId(productId);
    res.json(prices);
  });
  
  // Get all comparisons
  app.get("/api/comparisons", async (req, res) => {
    const comparisons = await storage.getComparisons();
    res.json(comparisons);
  });
  
  // Get comparison by slug
  app.get("/api/comparisons/:slug", async (req, res) => {
    const { slug } = req.params;
    const comparison = await storage.getComparisonBySlug(slug);
    
    if (!comparison) {
      return res.status(404).json({ message: "Comparison not found" });
    }
    
    res.json(comparison);
  });
  
  // Get comparisons by category
  app.get("/api/categories/:categoryId/comparisons", async (req, res) => {
    const categoryId = parseInt(req.params.categoryId);
    
    if (isNaN(categoryId)) {
      return res.status(400).json({ message: "Invalid category ID" });
    }
    
    const comparisons = await storage.getComparisonsByCategory(categoryId);
    res.json(comparisons);
  });
  
  // Get comparison products by comparison ID
  app.get("/api/comparisons/:comparisonId/products", async (req, res) => {
    const comparisonId = parseInt(req.params.comparisonId);
    
    if (isNaN(comparisonId)) {
      return res.status(400).json({ message: "Invalid comparison ID" });
    }
    
    const comparisonProducts = await storage.getComparisonProductsByComparisonId(comparisonId);
    
    // Get full product details for each comparison product
    const productDetailsPromises = comparisonProducts.map(async (cp) => {
      const product = await storage.getProductById(cp.productId);
      return {
        ...cp,
        product
      };
    });
    
    const productsWithDetails = await Promise.all(productDetailsPromises);
    res.json(productsWithDetails);
  });
  
  // Get all reviews
  app.get("/api/reviews", async (req, res) => {
    const reviews = await storage.getReviews();
    res.json(reviews);
  });
  
  // Get reviews by product ID
  app.get("/api/products/:productId/reviews", async (req, res) => {
    const productId = parseInt(req.params.productId);
    
    if (isNaN(productId)) {
      return res.status(400).json({ message: "Invalid product ID" });
    }
    
    const reviews = await storage.getReviewsByProductId(productId);
    res.json(reviews);
  });
  
  // Get review criteria by review ID
  app.get("/api/reviews/:reviewId/criteria", async (req, res) => {
    const reviewId = parseInt(req.params.reviewId);
    
    if (isNaN(reviewId)) {
      return res.status(400).json({ message: "Invalid review ID" });
    }
    
    const criteria = await storage.getReviewCriteriaByReviewId(reviewId);
    res.json(criteria);
  });
  
  // Get complete comparison with products and prices
  app.get("/api/comparisons/:slug/complete", async (req, res) => {
    const { slug } = req.params;
    const comparison = await storage.getComparisonBySlug(slug);
    
    if (!comparison) {
      return res.status(404).json({ message: "Comparison not found" });
    }
    
    const comparisonProducts = await storage.getComparisonProductsByComparisonId(comparison.id);
    
    const productsWithDetailsPromises = comparisonProducts.map(async (cp) => {
      const product = await storage.getProductById(cp.productId);
      if (!product) return null;
      
      const prices = await storage.getProductPricesByProductId(product.id);
      
      // Get retailer info for each price
      const pricesWithRetailerPromises = prices.map(async (price) => {
        const retailers = await storage.getRetailers();
        const retailer = retailers.find(r => r.id === price.retailerId);
        return {
          ...price,
          retailer
        };
      });
      
      const pricesWithRetailer = await Promise.all(pricesWithRetailerPromises);
      
      return {
        ...cp,
        product: {
          ...product,
          specifications: JSON.parse(product.specifications)
        },
        prices: pricesWithRetailer
      };
    });
    
    const productsWithDetails = await Promise.all(productsWithDetailsPromises);
    
    res.json({
      ...comparison,
      products: productsWithDetails.filter(p => p !== null)
    });
  });
  
  // Get detailed reviews for a product
  app.get("/api/products/:slug/detailed-reviews", async (req, res) => {
    const { slug } = req.params;
    const product = await storage.getProductBySlug(slug);
    
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }
    
    const reviews = await storage.getReviewsByProductId(product.id);
    
    const reviewsWithCriteriaPromises = reviews.map(async (review) => {
      const criteria = await storage.getReviewCriteriaByReviewId(review.id);
      return {
        ...review,
        criteria
      };
    });
    
    const reviewsWithCriteria = await Promise.all(reviewsWithCriteriaPromises);
    
    res.json({
      product: {
        ...product,
        specifications: JSON.parse(product.specifications)
      },
      reviews: reviewsWithCriteria
    });
  });
  
  // Search products
  app.get("/api/search", async (req, res) => {
    const query = (req.query.q as string || "").toLowerCase();
    
    if (!query || query.length < 2) {
      return res.status(400).json({ message: "Search query too short" });
    }
    
    const products = await storage.getProducts();
    
    const results = products.filter(product => 
      product.name.toLowerCase().includes(query) || 
      product.description.toLowerCase().includes(query)
    );
    
    res.json(results);
  });

  const httpServer = createServer(app);
  return httpServer;
}
