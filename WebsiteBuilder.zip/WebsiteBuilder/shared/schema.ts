import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema (keeping this from original)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Category schema
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  icon: text("icon").notNull(),
  colorClass: text("color_class").notNull(),
});

export const insertCategorySchema = createInsertSchema(categories).pick({
  name: true,
  slug: true,
  icon: true,
  colorClass: true,
});

// Product schema
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description").notNull(),
  imageUrl: text("image_url").notNull(),
  categoryId: integer("category_id").notNull(),
  price: integer("price").notNull(), // Price in cents
  rating: integer("rating").notNull(), // Rating out of 500
  specifications: text("specifications").notNull(),
  updatedAt: timestamp("updated_at").notNull(),
});

export const insertProductSchema = createInsertSchema(products).pick({
  name: true,
  slug: true,
  description: true,
  imageUrl: true,
  categoryId: true,
  price: true,
  rating: true,
  specifications: true,
  updatedAt: true,
});

// Retailer schema
export const retailers = pgTable("retailers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  logoUrl: text("logo_url").notNull(),
});

export const insertRetailerSchema = createInsertSchema(retailers).pick({
  name: true,
  slug: true,
  logoUrl: true,
});

// Product price by retailer
export const productPrices = pgTable("product_prices", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull(),
  retailerId: integer("retailer_id").notNull(),
  price: integer("price").notNull(), // Price in cents
  isPromotion: boolean("is_promotion").notNull().default(false),
  discountPercentage: integer("discount_percentage"),
  affiliateUrl: text("affiliate_url").notNull(),
});

export const insertProductPriceSchema = createInsertSchema(productPrices).pick({
  productId: true,
  retailerId: true,
  price: true,
  isPromotion: true,
  discountPercentage: true,
  affiliateUrl: true,
});

// Comparison schema
export const comparisons = pgTable("comparisons", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description").notNull(),
  imageUrl: text("image_url").notNull(),
  categoryId: integer("category_id").notNull(),
  updatedAt: timestamp("updated_at").notNull(),
});

export const insertComparisonSchema = createInsertSchema(comparisons).pick({
  title: true,
  slug: true,
  description: true,
  imageUrl: true,
  categoryId: true,
  updatedAt: true,
});

// Products in comparison
export const comparisonProducts = pgTable("comparison_products", {
  id: serial("id").primaryKey(),
  comparisonId: integer("comparison_id").notNull(),
  productId: integer("product_id").notNull(),
  order: integer("order").notNull(),
});

export const insertComparisonProductSchema = createInsertSchema(comparisonProducts).pick({
  comparisonId: true,
  productId: true,
  order: true,
});

// Review schema
export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull(),
  authorName: text("author_name").notNull(),
  authorAvatar: text("author_avatar").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  rating: integer("rating").notNull(), // Rating out of 500
  createdAt: timestamp("created_at").notNull(),
});

export const insertReviewSchema = createInsertSchema(reviews).pick({
  productId: true,
  authorName: true,
  authorAvatar: true,
  title: true,
  content: true,
  rating: true,
  createdAt: true,
});

// Review criteria
export const reviewCriteria = pgTable("review_criteria", {
  id: serial("id").primaryKey(),
  reviewId: integer("review_id").notNull(),
  name: text("name").notNull(),
  rating: integer("rating").notNull(), // Rating out of 500
});

export const insertReviewCriteriaSchema = createInsertSchema(reviewCriteria).pick({
  reviewId: true,
  name: true,
  rating: true,
});

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Category = typeof categories.$inferSelect;
export type InsertCategory = z.infer<typeof insertCategorySchema>;

export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;

export type Retailer = typeof retailers.$inferSelect;
export type InsertRetailer = z.infer<typeof insertRetailerSchema>;

export type ProductPrice = typeof productPrices.$inferSelect;
export type InsertProductPrice = z.infer<typeof insertProductPriceSchema>;

export type Comparison = typeof comparisons.$inferSelect;
export type InsertComparison = z.infer<typeof insertComparisonSchema>;

export type ComparisonProduct = typeof comparisonProducts.$inferSelect;
export type InsertComparisonProduct = z.infer<typeof insertComparisonProductSchema>;

export type Review = typeof reviews.$inferSelect;
export type InsertReview = z.infer<typeof insertReviewSchema>;

export type ReviewCriteria = typeof reviewCriteria.$inferSelect;
export type InsertReviewCriteria = z.infer<typeof insertReviewCriteriaSchema>;
