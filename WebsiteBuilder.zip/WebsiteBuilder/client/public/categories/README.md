
Pour les images des catégories, ajoutez des fichiers .jpg avec les noms suivants :
- gaming.jpg
- son-video.jpg
- sport-loisir.jpg
- cuisine.jpg
- maison-entretien.jpg
- tech.jpg
- forme-beaute.jpg

Format recommandé : 300x300px
