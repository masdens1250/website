import { useContext, useEffect, useState } from "react";

interface ThemeContextType {
  theme: string;
  setTheme: (theme: string) => void;
}

export function useTheme(): ThemeContextType {
  const [theme, setThemeState] = useState<string>("light"); // Force light theme

  useEffect(() => {
    // Update body class for dark/light mode
    if (theme === "dark") {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }

    // Store in localStorage
    localStorage.setItem("boutiquez-theme", theme);
  }, [theme]);

  const setTheme = (newTheme: string) => {
    setThemeState(newTheme);
  };

  return { theme, setTheme };
}
