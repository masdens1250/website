import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Format price from cents to currency string
export function formatPrice(price: number) {
  return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(price / 100);
}

// Render star rating value to string (e.g. 450 -> 4.5)
export function formatRating(rating: number) {
  return (rating / 100).toFixed(1);
}

// Calculate time difference in human-readable format
export function getTimeAgo(date: Date) {
  const now = new Date();
  const diffInDays = Math.floor((now.getTime() - new Date(date).getTime()) / (1000 * 60 * 60 * 24));
  
  if (diffInDays === 0) return "aujourd'hui";
  if (diffInDays === 1) return "hier";
  if (diffInDays < 7) return `il y a ${diffInDays} jours`;
  if (diffInDays < 30) return `il y a ${Math.floor(diffInDays / 7)} semaines`;
  return `il y a ${Math.floor(diffInDays / 30)} mois`;
}

// Truncate text with ellipsis
export function truncateText(text: string, maxLength: number) {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength) + '...';
}

// Slugify a string (convert to URL-friendly format)
export function slugify(text: string) {
  return text
    .toString()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim()
    .replace(/\s+/g, '-')
    .replace(/[^\w-]+/g, '')
    .replace(/--+/g, '-');
}
