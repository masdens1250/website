import { Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/hooks/use-theme";

export function ThemeToggle() {
  // On utilise toujours le hook, mais on ne réagit pas au clic
  const { theme } = useTheme();

  return (
    <Button
      variant="ghost"
      size="icon"
      disabled={true} // Désactiver le bouton
      aria-label="Mode clair activé"
    >
      <Sun className="h-5 w-5" />
    </Button>
  );
}
