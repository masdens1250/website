import { useState, useEffect, useRef } from "react";
import { Search, Zap, TrendingUp, ShieldCheck, Sparkles, Bell, BarChart4, Tag } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Category } from "@shared/schema";
import { motion, useAnimation, useInView } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";

export default function HeroSection() {
  const [searchQuery, setSearchQuery] = useState("");
  const [animateHero, setAnimateHero] = useState(false);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: false });
  const controls = useAnimation();
  
  const { data: categories } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  useEffect(() => {
    // Trigger animation after component mounts
    setAnimateHero(true);
    
    if (isInView) {
      controls.start("visible");
    }
  }, [controls, isInView]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Searching for:", searchQuery);
  };
  
  return (
    <section className="pb-6" ref={ref}>
      {/* Amazon-style main banner */}
      <div className="bg-gradient-to-r from-blue-900 to-blue-700 pt-4 pb-8">
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-5xl mx-auto">
            {/* Hero Title - Amazon Style */}
            <div className="text-center mb-6">
              <motion.h1 
                className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 text-white"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                Comparez les prix & économisez
              </motion.h1>
              <motion.p 
                className="text-base md:text-lg text-white/90 mb-6"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.2, duration: 0.5 }}
              >
                Trouvez les <span className="font-semibold">meilleurs prix</span> parmi des milliers de produits
              </motion.p>
              
              {/* Search bar Amazon Style */}
              <motion.div 
                className="relative flex flex-col sm:flex-row mx-auto max-w-3xl"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3, duration: 0.5 }}
              >
                <div className="relative flex-grow">
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                    <Search className="h-5 w-5" />
                  </div>
                  <input 
                    type="text" 
                    placeholder="Que recherchez-vous ? (Smartphone, TV, PS5...)" 
                    className="block w-full p-3 pl-10 text-gray-700 border-y border-l border-gray-300 focus:ring-0 focus:outline-none focus:border-blue-500 rounded-l-sm"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <button 
                  type="button" 
                  onClick={handleSubmit}
                  className="bg-yellow-400 hover:bg-yellow-500 text-gray-900 font-medium p-3 border border-yellow-500 rounded-r-sm sm:w-auto w-full mt-2 sm:mt-0 transition-colors"
                >
                  Rechercher
                </button>
              </motion.div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="container mx-auto px-4">
        {/* Popular categories - horizontal scrolling */}
        <div className="bg-white border border-gray-200 p-3 mb-4 overflow-x-auto">
          <div className="flex space-x-4 min-w-max">
            {categories?.slice(0, 8).map((category, index) => (
              <motion.div
                key={category.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 * index, duration: 0.3 }}
              >
                <Link href={`/category/${category.slug}`}>
                  <a className="text-sm text-blue-600 hover:underline whitespace-nowrap">
                    {category.name}
                  </a>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
        
        {/* Special Offers - Amazon Style Cards */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-xl font-medium">Offres exclusives</h2>
            <Link href="/deals">
              <a className="text-sm text-blue-600 hover:underline">Voir plus</a>
            </Link>
          </div>
          
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {Array.from({ length: 6 }).map((_, index) => (
              <motion.div 
                key={index} 
                className="bg-white border border-gray-200 p-3 hover:shadow-md transition-shadow"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * index, duration: 0.3 }}
              >
                <div className="relative mb-2">
                  <img 
                    src={`https://picsum.photos/200/200?random=${index + 1}`} 
                    alt="Offre spéciale" 
                    className="w-full aspect-square object-contain mix-blend-multiply"
                  />
                  <div className="absolute top-0 right-0 bg-red-600 text-white text-xs font-bold py-1 px-2">
                    -{Math.floor(Math.random() * 30) + 10}%
                  </div>
                </div>
                <div className="mb-2">
                  <span className="text-xs bg-red-100 text-red-800 px-2 py-0.5 rounded-sm">Offre limitée</span>
                </div>
                <h3 className="text-sm font-medium line-clamp-2 h-10">
                  {[
                    "Écouteurs sans fil avec réduction de bruit",
                    "Smartphone 5G avec caméra 50MP",
                    "Montre connectée étanche",
                    "Tablette 10 pouces haute résolution",
                    "Ordinateur portable ultraléger",
                    "Enceinte Bluetooth portable"
                  ][index]}
                </h3>
                <div className="mt-1">
                  <span className="text-lg font-bold text-black">{(19.99 + (index * 40)).toFixed(2)} €</span>
                  <span className="text-xs text-gray-500 line-through ml-1">
                    {(29.99 + (index * 50)).toFixed(2)} €
                  </span>
                </div>
                <button className="mt-2 w-full bg-yellow-400 hover:bg-yellow-500 text-gray-800 text-xs font-medium py-1 px-2 rounded-sm border border-yellow-500 transition-colors">
                  Voir les prix
                </button>
              </motion.div>
            ))}
          </div>
        </div>
        
        {/* Features - minimalist Amazon style */}
        <div className="bg-white border border-gray-200 p-4 mb-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {[
              { 
                icon: <Zap className="h-5 w-5" />, 
                title: "Comparaison en temps réel", 
                description: "Prix mis à jour toutes les heures"
              },
              { 
                icon: <TrendingUp className="h-5 w-5" />, 
                title: "Historique des prix", 
                description: "Suivez les baisses de prix"
              },
              { 
                icon: <ShieldCheck className="h-5 w-5" />, 
                title: "Avis vérifiés", 
                description: "Par des acheteurs confirmés"
              }
            ].map((feature, index) => (
              <motion.div 
                key={index} 
                className="flex items-start"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 * index, duration: 0.3 }}
              >
                <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 mr-3 shrink-0">
                  {feature.icon}
                </div>
                <div>
                  <h3 className="text-sm font-bold mb-1">{feature.title}</h3>
                  <p className="text-xs text-gray-600">{feature.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
        
        {/* Stats Counter - smaller version */}
        <div className="bg-blue-50 border border-blue-100 p-4 mb-6">
          <div className="flex flex-wrap justify-around gap-4 text-center">
            {[
              { value: "1M+", label: "Produits analysés" },
              { value: "75+", label: "Sites comparés" },
              { value: "30%", label: "Économies moyennes" }
            ].map((stat, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.1 * index, duration: 0.3 }}
              >
                <div className="text-xl font-bold text-blue-700">{stat.value}</div>
                <div className="text-xs text-gray-700">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
