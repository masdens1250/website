import { useState } from "react";

export default function NewsletterSection() {
  const [email, setEmail] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState("");
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate email
    if (!email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
      setError("Veuillez entrer une adresse email valide");
      return;
    }
    
    setIsSubmitting(true);
    setError("");
    
    // Simulate API call
    setTimeout(() => {
      console.log("Newsletter subscription for:", email);
      setIsSubmitting(false);
      setIsSuccess(true);
      setEmail("");
      
      // Reset success message after 3 seconds
      setTimeout(() => setIsSuccess(false), 3000);
    }, 1000);
  };
  
  return (
    <section className="py-12 bg-primary dark:bg-primary-900">
      <div className="container mx-auto">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-2xl font-bold text-white mb-4">Restez informé des meilleures offres</h2>
          <p className="text-primary-100 mb-8">
            Inscrivez-vous à notre newsletter pour recevoir les derniers comparatifs et bons plans directement dans votre boîte mail.
          </p>
          
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-2 max-w-lg mx-auto">
            <input 
              type="email" 
              placeholder="Votre adresse email" 
              className="flex-grow px-4 py-3 rounded-lg border-0 focus:ring-2 focus:ring-white"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={isSubmitting}
            />
            <button 
              type="submit" 
              className="px-6 py-3 bg-white text-primary font-medium rounded-lg hover:bg-gray-100 transition disabled:opacity-70"
              disabled={isSubmitting}
            >
              {isSubmitting ? "Inscription..." : "S'abonner"}
            </button>
          </form>
          
          {error && (
            <p className="text-red-200 text-sm mt-2">
              {error}
            </p>
          )}
          
          {isSuccess && (
            <p className="text-green-200 text-sm mt-2">
              Merci ! Vous êtes maintenant inscrit à notre newsletter.
            </p>
          )}
          
          <p className="text-primary-200 text-sm mt-4">
            En vous inscrivant, vous acceptez notre politique de confidentialité. Vous pourrez vous désinscrire à tout moment.
          </p>
        </div>
      </div>
    </section>
  );
}
