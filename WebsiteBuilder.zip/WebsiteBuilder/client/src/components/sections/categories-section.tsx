import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Category } from "@shared/schema";
import { Gamepad, Headphones, Activity, UtensilsCrossed, Home, Laptop, Sparkles } from "lucide-react";

// Map category icon names to actual components
const getCategoryIcon = (iconName: string, className: string) => {
  switch (iconName) {
    case "fa-gamepad":
      return <Gamepad className={className} />;
    case "fa-headphones":
      return <Headphones className={className} />;
    case "fa-running":
      return <Activity className={className} />;
    case "fa-utensils":
      return <UtensilsCrossed className={className} />;
    case "fa-home":
      return <Home className={className} />;
    case "fa-laptop":
      return <Laptop className={className} />;
    case "fa-spa":
      return <Sparkles className={className} />;
    default:
      return <Laptop className={className} />;
  }
};

export default function CategoriesSection() {
  const { data: categories, isLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  if (isLoading) {
    return (
      <section className="py-12 bg-white dark:bg-gray-900">
        <div className="container mx-auto">
          <h2 className="text-2xl font-bold mb-8 text-center">Catégories populaires</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
            {[...Array(7)].map((_, i) => (
              <div key={i} className="animate-pulse flex flex-col items-center p-4">
                <div className="w-16 h-16 rounded-full bg-gray-200 dark:bg-gray-700 mb-3"></div>
                <div className="h-4 w-20 bg-gray-200 dark:bg-gray-700 rounded"></div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-4 sm:py-6 border-b border-gray-200">
      <div className="container mx-auto px-4">
        <h2 className="text-xl font-medium mb-4 pl-1">Vos catégories</h2>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-x-3 gap-y-6">
          {categories?.map((category) => (
            <Link key={category.id} href={`/category/${category.slug}`}>
              <a className="flex flex-col">
                <div className="mb-2 relative group overflow-hidden bg-gray-100 rounded-sm aspect-square flex items-center justify-center">
                  {getCategoryIcon(category.icon, "w-12 h-12 text-gray-600")}
                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-10 transition-all duration-300"></div>
                </div>
                <span className="text-xs text-blue-700 hover:underline line-clamp-2">{category.name}</span>
              </a>
            </Link>
          ))}
        </div>

        <div className="flex justify-center mt-6">
          <Link href="/categories">
            <a className="text-sm text-blue-600 hover:text-blue-800 hover:underline">
              Voir toutes les catégories
            </a>
          </Link>
        </div>
      </div>
    </section>
  );
}