import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { ArrowRight } from "lucide-react";
import { Review, Product, ReviewCriteria } from "@shared/schema";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

// Format price from cents to currency string
const formatPrice = (price: number) => {
  return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(price / 100);
};

// Calculate time difference in human-readable format
const getTimeAgo = (date: Date) => {
  const now = new Date();
  const diffInDays = Math.floor((now.getTime() - new Date(date).getTime()) / (1000 * 60 * 60 * 24));
  
  if (diffInDays === 0) return "aujourd'hui";
  if (diffInDays === 1) return "hier";
  if (diffInDays < 7) return `il y a ${diffInDays} jours`;
  if (diffInDays < 30) return `il y a ${Math.floor(diffInDays / 7)} semaines`;
  return `il y a ${Math.floor(diffInDays / 30)} mois`;
};

// Render star rating
const StarRating = ({ rating }: { rating: number }) => {
  const starCount = Math.floor(rating / 100);
  const hasHalfStar = (rating % 100) >= 50;
  
  return (
    <div className="flex">
      {[...Array(5)].map((_, i) => {
        if (i < starCount) {
          return <span key={i} className="text-yellow-400">★</span>;
        } else if (i === starCount && hasHalfStar) {
          return <span key={i} className="text-yellow-400">★</span>;
        } else {
          return <span key={i} className="text-yellow-400">☆</span>;
        }
      })}
    </div>
  );
};

interface ExtendedReview extends Review {
  criteria: ReviewCriteria[];
  product: Product;
}

export default function LatestReviewsSection() {
  const { data: reviews, isLoading: isLoadingReviews } = useQuery<Review[]>({
    queryKey: ["/api/reviews"],
  });
  
  const { data: products, isLoading: isLoadingProducts } = useQuery<Product[]>({
    queryKey: ["/api/products"],
    enabled: !!reviews,
  });
  
  // Create a single query for all review criteria based on review IDs
  const { data: allCriteria, isLoading: isLoadingCriteria } = useQuery<{[reviewId: number]: ReviewCriteria[]}>({
    queryKey: ["/api/review-criteria", reviews ? reviews.map(r => r.id) : []],
    enabled: !!reviews,
    queryFn: async () => {
      if (!reviews || reviews.length === 0) return {};
      
      // Prepare an object to store criteria by review ID
      const criteriaByReviewId: {[reviewId: number]: ReviewCriteria[]} = {};
      
      // For each review, fetch its criteria
      await Promise.all(reviews.map(async (review) => {
        try {
          const response = await fetch(`/api/reviews/${review.id}/criteria`);
          const data = await response.json();
          criteriaByReviewId[review.id] = data;
        } catch (error) {
          console.error(`Failed to fetch criteria for review ${review.id}`, error);
          criteriaByReviewId[review.id] = [];
        }
      }));
      
      return criteriaByReviewId;
    }
  });
  
  // Combined loading state
  const isLoading = isLoadingReviews || isLoadingProducts || isLoadingCriteria;
  
  // Wait for all data to be loaded
  if (isLoading || !reviews || !products || !allCriteria) {
    return (
      <section className="py-12 bg-gray-50 dark:bg-gray-800">
        <div className="container mx-auto">
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-8">
            <h2 className="text-2xl font-bold">Derniers avis produits</h2>
            <div className="h-4 w-24 bg-gray-200 dark:bg-gray-700 rounded mt-2 md:mt-0"></div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="bg-white dark:bg-gray-900 rounded-lg shadow overflow-hidden animate-pulse flex flex-col">
                <div className="p-5 flex-grow">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-gray-200 dark:bg-gray-700 rounded-full"></div>
                      <div className="ml-3">
                        <div className="h-4 w-20 bg-gray-200 dark:bg-gray-700 rounded"></div>
                        <div className="h-3 w-32 bg-gray-200 dark:bg-gray-700 rounded mt-1"></div>
                      </div>
                    </div>
                    <div className="h-4 w-16 bg-gray-200 dark:bg-gray-700 rounded"></div>
                  </div>
                  
                  <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-3/4 mb-4"></div>
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-full mb-2"></div>
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-full mb-4"></div>
                </div>
                
                <div className="px-5 py-3 bg-gray-50 dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-gray-200 dark:bg-gray-700 rounded-lg mr-3"></div>
                    <div>
                      <div className="h-4 w-28 bg-gray-200 dark:bg-gray-700 rounded"></div>
                      <div className="h-3 w-16 bg-gray-200 dark:bg-gray-700 rounded mt-1"></div>
                    </div>
                  </div>
                  <div className="h-4 w-28 bg-gray-200 dark:bg-gray-700 rounded"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }
  
  // Combine review data with criteria and product data
  const extendedReviews: ExtendedReview[] = reviews.map((review) => {
    const productForReview = products.find(p => p.id === review.productId)!;
    return {
      ...review,
      criteria: allCriteria[review.id] || [],
      product: productForReview
    };
  });
  
  // Format date in Amazon style
  const formatDate = (date: Date) => {
    return format(new Date(date), 'dd MMMM yyyy', { locale: fr });
  };
  
  return (
    <section className="py-6 border-b border-gray-200">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-medium">Derniers avis clients</h2>
          <Link href="/reviews">
            <a className="text-sm text-blue-600 hover:text-blue-800 hover:underline flex items-center">
              Tous les avis <ArrowRight className="ml-1 h-3 w-3" />
            </a>
          </Link>
        </div>
        
        {/* Amazon style reviews layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {extendedReviews.slice(0, 2).map((review) => (
            <div key={review.id} className="border border-gray-200 bg-white">
              {/* Review header - Amazon style */}
              <div className="flex gap-4 p-4 items-start border-b border-gray-200">
                <div className="flex-shrink-0">
                  <img 
                    src={review.product.imageUrl} 
                    alt={review.product.name} 
                    className="w-16 h-16 object-contain border border-gray-200" 
                  />
                </div>
                
                <div className="flex-grow">
                  <Link href={`/product/${review.product.slug}`}>
                    <a className="text-blue-600 hover:text-blue-800 hover:underline text-sm font-medium line-clamp-1 mb-1">
                      {review.product.name}
                    </a>
                  </Link>
                  
                  <div className="flex items-baseline gap-2 mb-1">
                    <div className="font-bold text-black">{formatPrice(review.product.price)}</div>
                    <div className="text-xs text-blue-600 border border-blue-100 bg-blue-50 px-1 py-0.5">
                      PRIME
                    </div>
                  </div>
                  
                  <div className="flex items-center">
                    <div className="flex mr-2">
                      <StarRating rating={review.product.rating} />
                    </div>
                    <Link href={`/product/${review.product.slug}#reviews`}>
                      <a className="text-xs text-blue-600 hover:text-blue-800 hover:underline">
                        {Math.floor(Math.random() * 200) + 50} évaluations
                      </a>
                    </Link>
                  </div>
                </div>
                
                <div>
                  <Link href={`/product/${review.product.slug}`}>
                    <a className="text-xs bg-yellow-400 hover:bg-yellow-500 text-gray-800 py-1.5 px-3 rounded-sm border border-yellow-500 transition-colors whitespace-nowrap flex items-center justify-center">
                      Voir l'offre
                    </a>
                  </Link>
                </div>
              </div>
              
              {/* Review content - Amazon style */}
              <div className="p-4">
                <div className="flex items-center mb-2">
                  <img 
                    src={review.authorAvatar} 
                    alt={review.authorName} 
                    className="w-8 h-8 rounded-full mr-2" 
                  />
                  <div>
                    <div className="text-sm font-medium">{review.authorName}</div>
                    <div className="text-xs text-gray-500">
                      {review.id % 2 === 0 && (
                        <span className="text-green-700 mr-2">Achat vérifié</span>
                      )}
                      Évalué le {formatDate(review.createdAt)}
                    </div>
                  </div>
                </div>
                
                <div className="flex items-start gap-2 mb-1">
                  <div className="flex">
                    <StarRating rating={review.rating} />
                  </div>
                  <h3 className="text-sm font-bold">{review.title}</h3>
                </div>
                
                <p className="text-sm text-gray-800 mb-3 line-clamp-3">
                  {review.content}
                </p>
                
                {/* Review criteria summary - Amazon style */}
                {review.criteria.length > 0 && (
                  <div className="mb-3 bg-gray-50 p-2 border border-gray-200">
                    <div className="grid grid-cols-2 gap-2">
                      {review.criteria.slice(0, 2).map((criterion) => (
                        <div key={criterion.id} className="flex justify-between items-center">
                          <div className="text-xs text-gray-700">{criterion.name}</div>
                          <div className="flex items-center">
                            <div className="w-16 h-1.5 bg-gray-200 rounded-full overflow-hidden mr-1">
                              <div 
                                className="h-full bg-yellow-400 rounded-full" 
                                style={{ width: `${(criterion.rating / 500) * 100}%` }}
                              ></div>
                            </div>
                            <span className="text-xs font-medium">{(criterion.rating / 100).toFixed(1)}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                <div className="flex justify-between items-center">
                  <Link href={`/product/${review.product.slug}`}>
                    <a className="text-xs text-blue-600 hover:text-blue-800 hover:underline font-medium">
                      Voir l'avis complet →
                    </a>
                  </Link>
                  
                  <div className="flex items-center text-xs space-x-2">
                    <button className="text-gray-500 hover:text-gray-700">Signaler</button>
                    <div className="h-3 w-px bg-gray-300"></div>
                    <button className="text-gray-500 hover:text-gray-700">Utile</button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {/* Amazon style top rated products */}
        <div className="mt-8 mb-4">
          <h3 className="text-lg font-medium mb-3">Produits les mieux notés</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-3">
            {products?.slice(0, 6).map((product) => (
              <Link key={product.id} href={`/product/${product.slug}`}>
                <a className="group">
                  <div className="border border-gray-200 p-3 hover:shadow-md transition-shadow">
                    <div className="aspect-square flex items-center justify-center mb-2">
                      <img 
                        src={product.imageUrl} 
                        alt={product.name} 
                        className="max-h-20 object-contain" 
                      />
                    </div>
                    <div className="text-xs font-medium line-clamp-2 h-8 mb-1 group-hover:text-blue-600 transition-colors">
                      {product.name}
                    </div>
                    <div className="flex">
                      <StarRating rating={product.rating} />
                    </div>
                    <div className="text-sm font-bold mt-1">
                      {formatPrice(product.price)}
                    </div>
                  </div>
                </a>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
