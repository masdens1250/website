import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { ArrowRight, Check, ShoppingCart, Award, Zap, PieChart, Sparkles } from "lucide-react";
import { motion } from "framer-motion";
import { 
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface DetailedComparisonProductPrice {
  id: number;
  productId: number;
  retailerId: number;
  price: number;
  isPromotion: boolean;
  discountPercentage: number | null;
  affiliateUrl: string;
  retailer: {
    id: number;
    name: string;
    slug: string;
    logoUrl: string;
  };
}

interface DetailedComparisonProduct {
  id: number;
  comparisonId: number;
  productId: number;
  order: number;
  product: {
    id: number;
    name: string;
    slug: string;
    description: string;
    imageUrl: string;
    categoryId: number;
    price: number;
    rating: number;
    specifications: {
      screen: string;
      battery: string;
      camera: string;
      processor: string;
      memory: string;
      storage: string;
    };
    updatedAt: string;
  };
  prices: DetailedComparisonProductPrice[];
}

interface DetailedComparison {
  id: number;
  title: string;
  slug: string;
  description: string;
  imageUrl: string;
  categoryId: number;
  updatedAt: string;
  products: DetailedComparisonProduct[];
}

// Format price from cents to currency string
const formatPrice = (price: number) => {
  return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(price / 100);
};

// Render star rating
const StarRating = ({ rating }: { rating: number }) => {
  const starCount = Math.floor(rating / 100);
  const hasHalfStar = (rating % 100) >= 50;
  
  return (
    <div className="flex items-center">
      <span className="text-yellow-500 mr-1">{(rating / 100).toFixed(1)}</span>
      <div className="rating-stars">
        {[...Array(5)].map((_, i) => {
          if (i < starCount) {
            return <span key={i} className="text-yellow-400">★</span>;
          } else if (i === starCount && hasHalfStar) {
            return <span key={i} className="text-yellow-400">★</span>;
          } else {
            return <span key={i} className="text-yellow-400">☆</span>;
          }
        })}
      </div>
    </div>
  );
};

export default function DetailedComparisonSection() {
  const [animate, setAnimate] = useState(false);
  const { data: comparison, isLoading } = useQuery<DetailedComparison>({
    queryKey: ["/api/comparisons/smartphones-haut-de-gamme/complete"],
  });
  
  useEffect(() => {
    // Trigger animation after component mounts
    setAnimate(true);
  }, []);
  
  if (isLoading || !comparison) {
    return (
      <section className="py-16 bg-gradient-to-b from-white to-gray-50">
        <div className="container mx-auto">
          <div className="text-center mb-10 animate-pulse">
            <div className="h-8 bg-gray-200 rounded-full w-1/2 mx-auto mb-4"></div>
            <div className="h-4 bg-gray-200 rounded-full w-3/4 mx-auto"></div>
          </div>
          
          <div className="overflow-hidden rounded-xl shadow-xl">
            <div className="h-96 bg-gray-200 rounded-xl w-full bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 animate-pulse"></div>
          </div>
        </div>
      </section>
    );
  }
  
  // Calculate the best product based on rating
  const bestRatedProduct = comparison.products.reduce(
    (best, current) => current.product.rating > best.product.rating ? current : best,
    comparison.products[0]
  );
  
  // Find the cheapest product
  const cheapestProduct = comparison.products.reduce((cheapest, current) => {
    const cheapestPrice = current.prices.reduce(
      (min, p) => p.price < min ? p.price : min,
      current.prices[0].price
    );
    
    const cheapestPriceSoFar = cheapest.prices.reduce(
      (min, p) => p.price < min ? p.price : min,
      cheapest.prices[0].price
    );
    
    return cheapestPrice < cheapestPriceSoFar ? current : cheapest;
  }, comparison.products[0]);
  
  return (
    <section className="py-20 bg-gradient-to-b from-white to-blue-50 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute -top-24 -right-24 w-48 h-48 bg-blue-500/5 rounded-full blur-3xl"></div>
      <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-blue-400/5 rounded-full blur-3xl"></div>
      
      <div className="container mx-auto px-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: animate ? 1 : 0, y: animate ? 0 : 20 }}
          transition={{ duration: 0.7 }}
          className="text-center mb-12"
        >
          <Badge variant="outline" className="mb-4 px-4 py-1 rounded-full border-blue-300 text-blue-600 bg-blue-50 shadow-sm">
            <Sparkles className="w-3.5 h-3.5 mr-1" /> 
            Top Comparaisons
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900">
            {comparison.title}
          </h2>
          <p className="text-gray-600 max-w-3xl mx-auto text-lg">
            {comparison.description}
          </p>
        </motion.div>
        
        {/* Feature Highlights */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
          {[
            {
              icon: <Award className="h-5 w-5" />,
              title: "Meilleur Produit",
              value: bestRatedProduct.product.name,
              badge: "Note " + (bestRatedProduct.product.rating / 100).toFixed(1) + "/5",
              color: "bg-blue-50 text-blue-700 border-blue-200",
              delay: 0.3
            },
            {
              icon: <Zap className="h-5 w-5" />,
              title: "Meilleur Prix",
              value: cheapestProduct.product.name,
              badge: formatPrice(cheapestProduct.prices.reduce((min, p) => p.price < min ? p.price : min, cheapestProduct.prices[0].price)),
              color: "bg-blue-100 text-blue-800 border-blue-200",
              delay: 0.5
            },
            {
              icon: <PieChart className="h-5 w-5" />,
              title: "Produits comparés",
              value: comparison.products.length + " produits",
              badge: "Mis à jour " + new Date(comparison.updatedAt).toLocaleDateString('fr-FR', {day: 'numeric', month: 'short'}),
              color: "bg-blue-50 text-blue-700 border-blue-200",
              delay: 0.7
            }
          ].map((highlight, index) => (
            <motion.div 
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: animate ? 1 : 0, y: animate ? 0 : 20 }}
              transition={{ duration: 0.6, delay: highlight.delay }}
              className="bg-white rounded-xl shadow-md border border-gray-100 p-5"
            >
              <div className="flex items-center mb-2">
                <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 mr-3">
                  {highlight.icon}
                </div>
                <h3 className="font-medium">{highlight.title}</h3>
              </div>
              <p className="font-semibold text-lg mb-2 truncate">{highlight.value}</p>
              <Badge variant="outline" className={`${highlight.color} border`}>{highlight.badge}</Badge>
            </motion.div>
          ))}
        </div>
        
        {/* Product Cards Instead of Table */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: animate ? 1 : 0 }}
          transition={{ duration: 0.7, delay: 0.8 }}
          className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8 mb-12"
        >
          {comparison.products.map((item, index) => {
            const bestPrice = item.prices.reduce(
              (min, p) => (p.price < min.price ? p : min),
              item.prices[0]
            );
            
            const isBestPrice = bestPrice.price === Math.min(
              ...comparison.products.map(p => 
                p.prices.reduce((min, price) => Math.min(min, price.price), Infinity)
              )
            );
            
            const isTopRated = item.product.rating === Math.max(
              ...comparison.products.map(p => p.product.rating)
            );
            
            return (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: animate ? 1 : 0, y: animate ? 0 : 30 }}
                transition={{ duration: 0.6, delay: 0.6 + index * 0.1 }}
                className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow overflow-hidden border border-gray-100"
              >
                {/* Product Image with Badges */}
                <div className="relative">
                  <img 
                    src={item.product.imageUrl} 
                    alt={item.product.name} 
                    className="w-full h-48 object-cover" 
                  />
                  {isBestPrice && (
                    <div className="absolute top-2 left-2">
                      <Badge className="bg-blue-600 text-white border-none">
                        <Zap className="w-3 h-3 mr-1" /> Meilleur Prix
                      </Badge>
                    </div>
                  )}
                  {isTopRated && (
                    <div className="absolute top-2 right-2">
                      <Badge className="bg-blue-500 text-white border-none">
                        <Award className="w-3 h-3 mr-1" /> Top Note
                      </Badge>
                    </div>
                  )}
                </div>
                
                {/* Product Info */}
                <div className="p-5">
                  <div className="mb-3">
                    <h3 className="font-bold text-lg mb-1 truncate">{item.product.name}</h3>
                    <div className="flex items-center justify-between">
                      <StarRating rating={item.product.rating} />
                      <span className="text-xl font-bold text-primary">
                        {formatPrice(bestPrice.price)}
                      </span>
                    </div>
                  </div>
                  
                  {/* Specs Overview */}
                  <div className="bg-gray-50 rounded-lg p-3 mb-4 text-sm">
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <div className="text-gray-500">Écran</div>
                        <div className="font-medium truncate">{item.product.specifications.screen}</div>
                      </div>
                      <div>
                        <div className="text-gray-500">Batterie</div>
                        <div className="font-medium truncate">{item.product.specifications.battery}</div>
                      </div>
                      <div>
                        <div className="text-gray-500">Appareil photo</div>
                        <div className="font-medium truncate">{item.product.specifications.camera}</div>
                      </div>
                      <div>
                        <div className="text-gray-500">Processeur</div>
                        <div className="font-medium truncate">{item.product.specifications.processor}</div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Price Comparison Retailers */}
                  <div className="mb-4">
                    <div className="text-gray-500 text-sm mb-2">Disponible chez :</div>
                    <div className="flex flex-wrap gap-2">
                      {item.prices.map((price) => (
                        <Popover key={price.id}>
                          <PopoverTrigger asChild>
                            <button className="bg-white border border-gray-200 rounded-md p-1 hover:bg-gray-50 transition-colors">
                              <img 
                                src={price.retailer.logoUrl} 
                                alt={price.retailer.name} 
                                className="h-6 w-auto" 
                              />
                            </button>
                          </PopoverTrigger>
                          <PopoverContent className="w-48 p-0">
                            <div className="p-3 border-b">
                              <div className="font-medium">{price.retailer.name}</div>
                              <div className="text-lg font-bold text-primary">{formatPrice(price.price)}</div>
                              {price.isPromotion && (
                                <Badge variant="outline" className="bg-blue-50 text-blue-600 border-blue-200 mt-1">
                                  Promo -{price.discountPercentage}%
                                </Badge>
                              )}
                            </div>
                            <div className="p-2">
                              <a 
                                href={price.affiliateUrl} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="block w-full text-center bg-primary hover:bg-primary/90 text-white py-1.5 px-3 rounded-md text-sm"
                              >
                                <ShoppingCart className="w-3.5 h-3.5 inline mr-1" /> Acheter
                              </a>
                            </div>
                          </PopoverContent>
                        </Popover>
                      ))}
                    </div>
                  </div>
                  
                  {/* Action Buttons */}
                  <div className="flex items-center space-x-2">
                    <Button size="sm" variant="outline" className="flex-1">
                      <Check className="mr-1 h-3.5 w-3.5" /> Comparer
                    </Button>
                    <Button asChild size="sm" className="flex-1 w-full">
                      <Link href={`/product/${item.product.slug}`}>
                        Voir détails
                      </Link>
                    </Button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </motion.div>
        
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: animate ? 1 : 0 }}
          transition={{ duration: 0.7, delay: 1 }}
          className="mt-10 text-center"
        >
          <Button asChild size="lg" className="px-6 py-6 rounded-xl text-lg font-medium">
            <Link href={`/comparison/${comparison.slug}`}>
              Voir le comparatif complet <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
