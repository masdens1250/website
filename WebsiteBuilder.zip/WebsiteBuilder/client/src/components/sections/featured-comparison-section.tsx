import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Comparison } from "@shared/schema";
import { ArrowRight } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

export default function FeaturedComparisonSection() {
  const { data: comparisons, isLoading } = useQuery<Comparison[]>({
    queryKey: ["/api/comparisons"],
  });
  
  if (isLoading) {
    return (
      <section className="py-12 bg-gray-50 dark:bg-gray-800">
        <div className="container mx-auto">
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-8">
            <h2 className="text-2xl font-bold">Comparatifs populaires</h2>
            <div className="h-4 w-40 bg-gray-200 dark:bg-gray-700 rounded mt-2 md:mt-0"></div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="bg-white dark:bg-gray-900 rounded-lg shadow overflow-hidden animate-pulse">
                <div className="w-full h-48 bg-gray-200 dark:bg-gray-700"></div>
                <div className="p-5">
                  <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-3/4 mb-4"></div>
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-full mb-2"></div>
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-full mb-4"></div>
                  <div className="flex items-center justify-between">
                    <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/3"></div>
                    <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/4"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }
  
  const formatDate = (date: Date) => {
    return format(new Date(date), 'dd MMMM yyyy', { locale: fr });
  };
  
  return (
    <section className="py-5 border-b border-gray-200">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-medium">Comparatifs populaires</h2>
          <Link href="/comparisons">
            <a className="text-sm text-blue-600 hover:text-blue-800 hover:underline flex items-center">
              Voir tous les comparatifs <ArrowRight className="ml-1 h-3 w-3" />
            </a>
          </Link>
        </div>
        
        {/* Comparison Grid - Amazon Style */}
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {comparisons?.slice(0, 4).map((comparison) => (
            <Link key={comparison.id} href={`/comparison/${comparison.slug}`}>
              <a className="group block">
                <div className="bg-white border border-gray-200 hover:shadow-md transition-shadow">
                  <div className="relative pt-[75%] overflow-hidden bg-gray-100">
                    <img 
                      src={comparison.imageUrl} 
                      alt={comparison.title} 
                      className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-3">
                      <div className="text-white text-sm font-medium">{comparison.title}</div>
                    </div>
                  </div>
                  <div className="p-3">
                    <div className="flex items-center mb-2">
                      <span className="bg-yellow-400 text-xs text-gray-800 font-bold px-2 py-0.5 mr-2">
                        TOP VENTES
                      </span>
                      <span className="text-xs text-gray-500">
                        {new Date(comparison.updatedAt).toLocaleDateString('fr-FR', {day: 'numeric', month: 'short'})}
                      </span>
                    </div>
                    
                    <p className="text-xs text-gray-600 line-clamp-2 mb-2 h-8">
                      {comparison.description}
                    </p>
                    
                    <div className="text-sm text-blue-600 font-medium group-hover:underline">
                      Comparer les produits
                    </div>
                  </div>
                </div>
              </a>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
