import { useState } from "react";
import { Link } from "wouter";
import { Check, ShoppingCart, Info, ChevronDown, ChevronUp } from "lucide-react";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";

interface ComparisonRetailer {
  id: number;
  name: string;
  slug: string;
  logoUrl: string;
}

interface ComparisonPrice {
  id: number;
  productId: number;
  retailerId: number;
  price: number;
  isPromotion: boolean;
  discountPercentage: number | null;
  affiliateUrl: string;
  retailer: ComparisonRetailer;
}

interface ComparisonProductSpecs {
  screen: string;
  battery: string;
  camera: string;
  processor: string;
  memory: string;
  storage: string;
  [key: string]: string;
}

interface ComparisonProduct {
  id: number;
  comparisonId: number;
  productId: number;
  order: number;
  product: {
    id: number;
    name: string;
    slug: string;
    description: string;
    imageUrl: string;
    categoryId: number;
    price: number;
    rating: number;
    specifications: ComparisonProductSpecs;
    updatedAt: string;
  };
  prices: ComparisonPrice[];
}

interface ComparisonTableProps {
  title: string;
  description: string;
  products: ComparisonProduct[];
}

// Format price from cents to currency string
const formatPrice = (price: number) => {
  return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(price / 100);
};

// Render star rating
const StarRating = ({ rating }: { rating: number }) => {
  const starCount = Math.floor(rating / 100);
  const hasHalfStar = (rating % 100) >= 50;
  
  return (
    <div className="flex items-center">
      <span className="text-yellow-500 mr-1">{(rating / 100).toFixed(1)}</span>
      <div className="rating-stars">
        {[...Array(5)].map((_, i) => {
          if (i < starCount) {
            return <span key={i}>★</span>;
          } else if (i === starCount && hasHalfStar) {
            return <span key={i}>★</span>;
          } else {
            return <span key={i}>☆</span>;
          }
        })}
      </div>
    </div>
  );
};

export default function ComparisonTable({ title, description, products }: ComparisonTableProps) {
  const [showAllSpecs, setShowAllSpecs] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState<string | null>(null);
  
  // Get all specification keys
  const allSpecKeys = new Set<string>();
  products.forEach(p => {
    Object.keys(p.product.specifications).forEach(key => allSpecKeys.add(key));
  });
  
  // Default specs to show - Amazon style focuses on fewer but important specs
  const defaultSpecs = ['screen', 'processor', 'memory'];
  
  // Specs to show based on showAllSpecs state
  const specsToShow = showAllSpecs 
    ? Array.from(allSpecKeys) 
    : defaultSpecs.filter(spec => allSpecKeys.has(spec));
  
  // Get the best price for each product
  const getLowestPrice = (prices: ComparisonPrice[]) => {
    return prices.reduce((min, p) => p.price < min.price ? p : min, prices[0]);
  };
  
  // Calculate the absolute best price among all products
  const lowestPrices = products.map(p => getLowestPrice(p.prices).price);
  const absoluteLowestPrice = Math.min(...lowestPrices);
  
  // Get random delivery date (Amazon style)
  const getDeliveryDate = () => {
    const date = new Date();
    date.setDate(date.getDate() + Math.floor(Math.random() * 3) + 1);
    return date.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long' });
  };
  
  return (
    <div className="bg-white">
      <div className="container mx-auto px-4 py-4">
        <div className="mb-6">
          <h1 className="text-xl font-medium mb-1">{title}</h1>
          <p className="text-sm text-gray-600 max-w-3xl">
            {description}
          </p>
        </div>
        
        {/* Amazon style filter bar */}
        <div className="bg-gray-100 p-3 mb-4 border border-gray-200 flex flex-wrap items-center gap-4">
          <div className="text-sm font-bold">Filtrer par:</div>
          {Array.from(allSpecKeys).slice(0, 4).map(key => (
            <button
              key={key}
              className={`text-xs px-3 py-1.5 rounded-full border ${
                selectedFilter === key 
                  ? 'bg-blue-100 border-blue-300 text-blue-800' 
                  : 'bg-white border-gray-300 text-gray-700'
              }`}
              onClick={() => setSelectedFilter(selectedFilter === key ? null : key)}
            >
              {key === 'screen' ? 'Écran' : 
               key === 'battery' ? 'Batterie' : 
               key === 'camera' ? 'Appareil photo' : 
               key === 'processor' ? 'Processeur' :
               key === 'memory' ? 'Mémoire' :
               key === 'storage' ? 'Stockage' : key}
            </button>
          ))}
        </div>
        
        {/* Products comparison - Amazon style */}
        <div className="mb-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {products.map((item) => {
            const bestPrice = getLowestPrice(item.prices);
            const isBestPrice = bestPrice.price === absoluteLowestPrice;
            const isPrime = item.id % 2 === 0; // Simuler Prime
            
            return (
              <div key={item.id} className="border border-gray-200 p-4 relative">
                {/* Top badges */}
                <div className="flex gap-2 mb-3">
                  {isPrime && (
                    <span className="bg-blue-100 text-blue-800 text-xs px-2 py-0.5 font-bold">
                      PRIME
                    </span>
                  )}
                  {isBestPrice && (
                    <span className="bg-orange-100 text-orange-800 text-xs px-2 py-0.5 font-bold">
                      MEILLEUR PRIX
                    </span>
                  )}
                  {bestPrice.isPromotion && (
                    <span className="bg-red-100 text-red-800 text-xs px-2 py-0.5 font-bold">
                      -{bestPrice.discountPercentage}%
                    </span>
                  )}
                </div>
                
                {/* Product image and name */}
                <div className="flex flex-col items-center mb-4">
                  <Link href={`/product/${item.product.slug}`}>
                    <a className="hover:opacity-90 transition-opacity">
                      <img 
                        src={item.product.imageUrl} 
                        alt={item.product.name} 
                        className="h-36 w-auto object-contain mb-3" 
                      />
                      <h3 className="text-center text-sm font-medium hover:text-blue-600 line-clamp-2">
                        {item.product.name}
                      </h3>
                    </a>
                  </Link>
                  
                  <div className="mt-2 flex items-center">
                    <StarRating rating={item.product.rating} />
                    <Link href={`/product/${item.product.slug}#reviews`}>
                      <a className="text-xs text-blue-600 hover:text-orange-600 hover:underline ml-2">
                        ({Math.floor(Math.random() * 200) + 50})
                      </a>
                    </Link>
                  </div>
                </div>
                
                {/* Price section - Amazon style */}
                <div className="mt-auto">
                  <div className="text-lg font-bold">{formatPrice(bestPrice.price)}</div>
                  
                  {/* Delivery badge */}
                  <div className="text-xs text-green-700 font-medium mt-1">
                    Livraison GRATUITE d'ici le {getDeliveryDate()}
                  </div>
                  
                  {/* Specs highlight - Amazon style */}
                  <div className="mt-4 mb-4">
                    <h4 className="text-xs font-bold uppercase mb-2 text-gray-500">Caractéristiques:</h4>
                    <ul className="text-xs space-y-1">
                      {specsToShow.slice(0, 3).map(spec => (
                        <li key={spec} className="flex">
                          <span className="text-gray-600 mr-2">•</span>
                          <span className="capitalize">{spec === 'screen' ? 'Écran' : 
                            spec === 'battery' ? 'Batterie' : 
                            spec === 'camera' ? 'App. photo' : 
                            spec === 'processor' ? 'Proc.' :
                            spec === 'memory' ? 'Mém.' :
                            spec === 'storage' ? 'Stock.' : spec}:</span>
                          <span className="ml-1 text-gray-700">{item.product.specifications[spec] || 'N/A'}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  {/* Price comparison section */}
                  <div className="grid gap-2 mb-3">
                    {item.prices.slice(0, 3).map((price) => (
                      <a 
                        key={price.id}
                        href={price.affiliateUrl} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-xs flex items-center justify-between p-1.5 border border-gray-200 rounded hover:bg-gray-50 transition-colors"
                      >
                        <div className="flex items-center">
                          <img 
                            src={price.retailer.logoUrl} 
                            alt={price.retailer.name} 
                            className="h-4 w-4 object-contain mr-2" 
                          />
                          <span className="text-gray-600">{price.retailer.name}</span>
                        </div>
                        <span className="font-bold text-black">{formatPrice(price.price)}</span>
                      </a>
                    ))}
                  </div>
                  
                  {/* Action buttons */}
                  <div className="grid grid-cols-2 gap-2">
                    <Link href={`/product/${item.product.slug}`}>
                      <a className="text-center bg-gray-100 hover:bg-gray-200 text-gray-800 text-xs font-medium py-2 rounded-sm border border-gray-300 transition-colors">
                        Voir détails
                      </a>
                    </Link>
                    <a 
                      href={bestPrice.affiliateUrl}
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-center bg-yellow-400 hover:bg-yellow-500 text-gray-800 text-xs font-medium py-2 rounded-sm border border-yellow-500 transition-colors">
                      Voir le prix
                    </a>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        
        {/* Show all specs button - Amazon style */}
        <div className="flex justify-center mt-4 mb-6">
          <Button 
            variant="outline"
            size="sm"
            className="text-xs flex items-center"
            onClick={() => setShowAllSpecs(!showAllSpecs)}
          >
            {showAllSpecs ? (
              <>
                <ChevronUp className="h-3 w-3 mr-1" />
                Réduire les caractéristiques
              </>
            ) : (
              <>
                <ChevronDown className="h-3 w-3 mr-1" />
                Voir toutes les caractéristiques
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
