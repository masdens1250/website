import { Link } from "wouter";
import { Product } from "@shared/schema";

// Format price from cents to currency string
const formatPrice = (price: number) => {
  return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(price / 100);
};

// Render star rating
const StarRating = ({ rating }: { rating: number }) => {
  const starCount = Math.floor(rating / 100);
  const hasHalfStar = (rating % 100) >= 50;
  
  return (
    <div className="flex items-center">
      <span className="text-yellow-500 mr-1">{(rating / 100).toFixed(1)}</span>
      <div className="rating-stars">
        {[...Array(5)].map((_, i) => {
          if (i < starCount) {
            return <span key={i}>★</span>;
          } else if (i === starCount && hasHalfStar) {
            return <span key={i}>★</span>;
          } else {
            return <span key={i}>☆</span>;
          }
        })}
      </div>
    </div>
  );
};

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  // Generate pseudo-random price discount for some products (simulate Amazon deals)
  const hasDiscount = product.price > 20000 && product.id % 3 === 0;
  const discountPercentage = hasDiscount ? Math.floor(Math.random() * 20) + 10 : 0;
  const originalPrice = hasDiscount ? product.price * (100 / (100 - discountPercentage)) : product.price;
  
  // Format dates for Amazon-style display
  const deliveryDate = new Date();
  deliveryDate.setDate(deliveryDate.getDate() + 2);
  const formattedDeliveryDate = deliveryDate.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long' });
  
  return (
    <Link href={`/product/${product.slug}`}>
      <a className="group">
        <div className="bg-white hover:shadow-md transition-shadow border border-gray-200 flex flex-col h-full p-3">
          {/* Prime badge */}
          {product.id % 2 === 0 && (
            <div className="text-xs text-blue-600 font-bold mb-1">
              <span className="bg-blue-100 px-1 py-0.5 rounded-sm">PRIME</span>
            </div>
          )}
          
          <div className="relative mb-2 flex items-center justify-center h-44 overflow-hidden">
            <img 
              src={product.imageUrl} 
              alt={product.name} 
              className="h-auto max-h-44 max-w-full object-contain mix-blend-multiply transform group-hover:scale-105 transition-transform duration-200"
            />
            
            {/* Discount badge - Amazon style */}
            {hasDiscount && (
              <div className="absolute top-0 right-0 bg-red-600 text-white text-xs font-bold py-1 px-2">
                -{discountPercentage}%
              </div>
            )}
          </div>
          
          <div className="flex-grow flex flex-col">
            <h3 className="text-sm font-medium line-clamp-2 mb-1 group-hover:text-blue-600 transition-colors">
              {product.name}
            </h3>
            
            <div className="mb-1 flex items-center">
              <StarRating rating={product.rating} />
              <span className="text-xs text-blue-600 hover:text-orange-600 hover:underline ml-1 cursor-pointer">
                ({Math.floor(Math.random() * 200) + 50})
              </span>
            </div>
            
            <div className="mt-auto">
              {/* Amazon style pricing */}
              <div className="flex flex-col">
                {hasDiscount && (
                  <div className="flex items-center mb-0.5">
                    <span className="text-xs text-gray-500 line-through">
                      {formatPrice(Math.round(originalPrice))}
                    </span>
                    <span className="text-xs text-red-600 ml-2 font-medium">
                      -{discountPercentage}%
                    </span>
                  </div>
                )}
                
                <div className="flex items-baseline">
                  <span className="text-lg font-bold text-black">{formatPrice(product.price)}</span>
                </div>
                
                {/* Amazon style delivery message */}
                <div className="text-xs text-green-700 mt-1 font-medium">
                  Livraison GRATUITE d'ici {formattedDeliveryDate}
                </div>
                
                {/* Amazon style inventory */}
                {product.id % 5 === 0 && (
                  <div className="text-xs text-red-600 mt-0.5 font-medium">
                    Plus que {Math.floor(Math.random() * 10) + 1} en stock
                  </div>
                )}
              </div>
              
              <button className="mt-2 w-full bg-yellow-400 hover:bg-yellow-500 text-gray-800 text-xs font-medium py-1.5 px-2 rounded-sm border border-yellow-500 transition-colors">
                Voir les prix
              </button>
            </div>
          </div>
        </div>
      </a>
    </Link>
  );
}
