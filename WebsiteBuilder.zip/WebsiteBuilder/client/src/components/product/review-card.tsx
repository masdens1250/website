import { Link } from "wouter";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { Review, ReviewCriteria, Product } from "@shared/schema";

// Format price from cents to currency string
const formatPrice = (price: number) => {
  return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(price / 100);
};

// Render star rating
const StarRating = ({ rating }: { rating: number }) => {
  const starCount = Math.floor(rating / 100);
  const hasHalfStar = (rating % 100) >= 50;
  
  return (
    <div className="flex">
      {[...Array(5)].map((_, i) => {
        if (i < starCount) {
          return <span key={i} className="text-yellow-400">★</span>;
        } else if (i === starCount && hasHalfStar) {
          return <span key={i} className="text-yellow-400">★</span>;
        } else {
          return <span key={i} className="text-yellow-400">☆</span>;
        }
      })}
    </div>
  );
};

// Calculate time difference in human-readable format
const getTimeAgo = (date: Date) => {
  const now = new Date();
  const diffInDays = Math.floor((now.getTime() - new Date(date).getTime()) / (1000 * 60 * 60 * 24));
  
  if (diffInDays === 0) return "aujourd'hui";
  if (diffInDays === 1) return "hier";
  if (diffInDays < 7) return `il y a ${diffInDays} jours`;
  if (diffInDays < 30) return `il y a ${Math.floor(diffInDays / 7)} semaines`;
  return `il y a ${Math.floor(diffInDays / 30)} mois`;
};

interface ReviewCardProps {
  review: Review;
  criteria: ReviewCriteria[];
  product: Product;
  showProduct?: boolean;
}

export default function ReviewCard({ review, criteria, product, showProduct = true }: ReviewCardProps) {
  // Format date in Amazon style
  const formatDate = (date: Date) => {
    return format(new Date(date), 'dd MMMM yyyy', { locale: fr });
  };
  
  // Calculate average criteria rating
  const avgCriteriaRating = criteria.reduce((sum, c) => sum + c.rating, 0) / (criteria.length || 1);
  
  // Check if review is verified (Amazon style)
  const isVerifiedPurchase = review.id % 2 === 0;
  
  return (
    <div className="border border-gray-200 mb-4">
      {/* Review header - Amazon style */}
      <div className="border-b border-gray-200 p-3 bg-gray-50 flex items-center">
        <div className="flex items-center">
          <img 
            src={review.authorAvatar} 
            alt={review.authorName} 
            className="w-8 h-8 rounded-full" 
          />
          <div className="ml-2">
            <div className="font-medium text-sm">{review.authorName}</div>
          </div>
        </div>
      </div>
      
      <div className="p-4">
        {/* Rating and title - Amazon style */}
        <div className="flex items-start mb-1">
          <div className="mr-2">
            <StarRating rating={review.rating} />
          </div>
          <h3 className="text-base font-bold text-gray-900">{review.title}</h3>
        </div>
        
        {/* Review metadata - Amazon style */}
        <div className="text-xs text-gray-500 mb-3">
          Évalué en France le {formatDate(review.createdAt)}
          {isVerifiedPurchase && (
            <span className="ml-2 text-xs text-green-700 font-medium">Achat vérifié</span>
          )}
        </div>
        
        {/* Review content - Amazon style */}
        <div className="mb-4">
          <p className="text-sm text-gray-800 whitespace-pre-line">
            {review.content}
          </p>
        </div>
        
        {/* Review criteria - Amazon style */}
        {criteria.length > 0 && (
          <div className="bg-gray-50 p-3 border border-gray-200 mb-4">
            <h4 className="text-xs font-bold uppercase mb-2 text-gray-500">Évaluation détaillée</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {criteria.map((criterion) => (
                <div key={criterion.id} className="flex justify-between items-center">
                  <div className="text-xs text-gray-700">{criterion.name}</div>
                  <div className="flex items-center">
                    <div className="w-24 h-1.5 bg-gray-200 rounded-full overflow-hidden mr-2">
                      <div 
                        className="h-full bg-yellow-400 rounded-full" 
                        style={{ width: `${(criterion.rating / 500) * 100}%` }}
                      ></div>
                    </div>
                    <span className="text-xs font-medium">{(criterion.rating / 100).toFixed(1)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {/* Helpful buttons - Amazon style */}
        <div className="flex items-center text-xs text-gray-500 border-t border-gray-200 pt-3 mt-3">
          <span className="mr-3">Cette évaluation vous a-t-elle été utile ?</span>
          <button className="border border-gray-300 rounded-sm py-1 px-3 mr-2 hover:bg-gray-100 transition-colors text-xs">
            Oui
          </button>
          <button className="border border-gray-300 rounded-sm py-1 px-3 hover:bg-gray-100 transition-colors text-xs">
            Non
          </button>
          <button className="ml-auto text-xs text-blue-600 hover:text-blue-800 hover:underline">
            Signaler
          </button>
        </div>
      </div>
      
      {/* Related product - Amazon style */}
      {showProduct && (
        <div className="px-4 py-3 bg-gray-50 border-t border-gray-200 flex items-center justify-between">
          <div className="flex items-center">
            <img 
              src={product.imageUrl} 
              alt={product.name} 
              className="w-10 h-10 rounded-lg mr-3 border border-gray-200 bg-white p-1" 
            />
            <div>
              <Link href={`/product/${product.slug}`}>
                <a className="font-medium text-xs text-blue-600 hover:text-blue-800 hover:underline">
                  {product.name}
                </a>
              </Link>
              <div className="text-xs font-bold text-black">
                {formatPrice(product.price)}
              </div>
            </div>
          </div>
          <Link href={`/product/${product.slug}`}>
            <a className="text-xs bg-yellow-400 hover:bg-yellow-500 text-gray-800 py-1 px-3 rounded-sm border border-yellow-500 transition-colors">
              Voir l'offre
            </a>
          </Link>
        </div>
      )}
    </div>
  );
}
