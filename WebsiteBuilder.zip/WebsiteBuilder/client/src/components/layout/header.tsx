import { useState } from "react";
import { Link, useLocation } from "wouter";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import { Search, Menu, ShoppingBasket } from "lucide-react";

const NavLink = ({ href, children }: { href: string; children: React.ReactNode }) => {
  const [location] = useLocation();
  const isActive = location === href;
  
  return (
    <Link href={href} className={isActive ? "nav-link-active" : "nav-link"}>
      {children}
    </Link>
  );
};

export default function Header() {
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Search for:", searchQuery);
    setSearchOpen(false);
  };
  
  return (
    <header className="sticky top-0 z-50 bg-white dark:bg-gray-800 shadow-sm">
      <div className="container mx-auto">
        <div className="flex items-center justify-between py-4">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2">
            <span className="text-primary dark:text-primary">
              <ShoppingBasket className="h-6 w-6" />
            </span>
            <span className="text-xl font-bold">Boutiquez</span>
          </Link>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <NavLink href="/">Accueil</NavLink>
            <NavLink href="/comparison/smartphones-haut-de-gamme">Comparatifs</NavLink>
            <NavLink href="/category/tech">Guides d'achat</NavLink>
            <NavLink href="/reviews">Avis</NavLink>
            <NavLink href="/contact">Contact</NavLink>
          </nav>
          
          <div className="flex items-center space-x-4">
            {/* Search button */}
            <Sheet open={searchOpen} onOpenChange={setSearchOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" aria-label="Search">
                  <Search className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="top" className="pt-16">
                <form onSubmit={handleSearchSubmit} className="w-full max-w-2xl mx-auto">
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="Rechercher un produit..."
                      className="w-full py-3 px-4 pr-12 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:ring-2 focus:ring-primary"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                    <button 
                      type="submit" 
                      className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-primary"
                    >
                      <Search className="h-5 w-5" />
                    </button>
                  </div>
                </form>
              </SheetContent>
            </Sheet>
            
            {/* Dark mode toggle */}
            <ThemeToggle />
            
            {/* Mobile menu button */}
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden" aria-label="Menu">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right">
                <nav className="flex flex-col space-y-4 mt-8">
                  <NavLink href="/">Accueil</NavLink>
                  <NavLink href="/comparison/smartphones-haut-de-gamme">Comparatifs</NavLink>
                  <NavLink href="/category/tech">Guides d'achat</NavLink>
                  <NavLink href="/reviews">Avis</NavLink>
                  <NavLink href="/contact">Contact</NavLink>
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
