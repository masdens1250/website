import { Link } from "wouter";
import { ShoppingBasket, Facebook, Twitter, Instagram, Youtube } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-400">
      <div className="container mx-auto py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <span className="text-white">
                <ShoppingBasket className="h-6 w-6" />
              </span>
              <span className="text-xl font-bold text-white">Boutiquez</span>
            </div>
            <p className="mb-4">
              Comparez les meilleurs produits du marché grâce à des tests et avis détaillés pour faire le meilleur choix.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition">
                <Facebook size={18} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition">
                <Twitter size={18} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition">
                <Instagram size={18} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition">
                <Youtube size={18} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-white font-semibold mb-4">Catégories</h3>
            <ul className="space-y-2">
              <li><Link href="/category/gaming" className="hover:text-white transition">Gaming</Link></li>
              <li><Link href="/category/son-video" className="hover:text-white transition">Son & Vidéo</Link></li>
              <li><Link href="/category/sport-loisir" className="hover:text-white transition">Sport & Loisir</Link></li>
              <li><Link href="/category/cuisine" className="hover:text-white transition">Cuisine</Link></li>
              <li><Link href="/category/maison-entretien" className="hover:text-white transition">Maison & Entretien</Link></li>
              <li><Link href="/category/tech" className="hover:text-white transition">Tech</Link></li>
              <li><Link href="/category/forme-beaute" className="hover:text-white transition">Forme & Beauté</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-semibold mb-4">Liens utiles</h3>
            <ul className="space-y-2">
              <li><a href="#" className="hover:text-white transition">À propos</a></li>
              <li><a href="#" className="hover:text-white transition">Comment nous testons</a></li>
              <li><a href="#" className="hover:text-white transition">Nos partenaires</a></li>
              <li><a href="#" className="hover:text-white transition">Programme d'affiliation</a></li>
              <li><Link href="/contact" className="hover:text-white transition">Nous contacter</Link></li>
              <li><a href="#" className="hover:text-white transition">FAQ</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-semibold mb-4">Informations légales</h3>
            <ul className="space-y-2">
              <li><a href="#" className="hover:text-white transition">Conditions d'utilisation</a></li>
              <li><a href="#" className="hover:text-white transition">Politique de confidentialité</a></li>
              <li><a href="#" className="hover:text-white transition">Politique de cookies</a></li>
              <li><a href="#" className="hover:text-white transition">Mentions légales</a></li>
            </ul>
            <p className="mt-4 text-sm">
              © {new Date().getFullYear()} Boutiquez. Tous droits réservés.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
