import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import ComparisonTable from "@/components/product/comparison-table";
import { ChevronRight } from "lucide-react";

interface ComparisonRetailer {
  id: number;
  name: string;
  slug: string;
  logoUrl: string;
}

interface ComparisonPrice {
  id: number;
  productId: number;
  retailerId: number;
  price: number;
  isPromotion: boolean;
  discountPercentage: number | null;
  affiliateUrl: string;
  retailer: ComparisonRetailer;
}

interface ComparisonProductSpecs {
  screen: string;
  battery: string;
  camera: string;
  processor: string;
  memory: string;
  storage: string;
  [key: string]: string;
}

interface ComparisonProduct {
  id: number;
  comparisonId: number;
  productId: number;
  order: number;
  product: {
    id: number;
    name: string;
    slug: string;
    description: string;
    imageUrl: string;
    categoryId: number;
    price: number;
    rating: number;
    specifications: ComparisonProductSpecs;
    updatedAt: string;
  };
  prices: ComparisonPrice[];
}

interface DetailedComparison {
  id: number;
  title: string;
  slug: string;
  description: string;
  imageUrl: string;
  categoryId: number;
  updatedAt: string;
  products: ComparisonProduct[];
}

export default function ComparisonPage() {
  const [, params] = useRoute("/comparison/:slug");
  const slug = params?.slug;

  const { data: comparison, isLoading } = useQuery<DetailedComparison>({
    queryKey: [`/api/comparisons/${slug}/complete`],
    enabled: !!slug,
  });

  // Set the document title based on the comparison title
  useEffect(() => {
    if (comparison) {
      document.title = `${comparison.title} - Boutiquez`;
    }
  }, [comparison]);

  if (isLoading) {
    return (
      <div className="container mx-auto py-8">
        <div className="animate-pulse mb-8">
          <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded-md w-1/2 mb-4"></div>
          <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded-md w-3/4 mb-4"></div>
          <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded-md w-2/3"></div>
        </div>
        <Skeleton className="w-full h-[500px] rounded-lg" />
      </div>
    );
  }

  if (!comparison) {
    return (
      <div className="container mx-auto py-16 text-center">
        <h1 className="text-2xl font-bold mb-4">Comparatif non trouvé</h1>
        <p className="text-gray-600 dark:text-gray-400 mb-6">
          Nous n'avons pas pu trouver le comparatif demandé.
        </p>
      </div>
    );
  }

  return (
    <>
      <div className="bg-gray-100 dark:bg-gray-800 py-6">
        <div className="container mx-auto">
          <div className="flex items-center text-sm">
            <a href="/" className="text-gray-500 dark:text-gray-400 hover:text-primary dark:hover:text-primary">
              Accueil
            </a>
            <ChevronRight className="h-4 w-4 mx-1 text-gray-400" />
            <a href="/comparisons" className="text-gray-500 dark:text-gray-400 hover:text-primary dark:hover:text-primary">
              Comparatifs
            </a>
            <ChevronRight className="h-4 w-4 mx-1 text-gray-400" />
            <span className="text-gray-900 dark:text-white font-medium">{comparison.title}</span>
          </div>
        </div>
      </div>

      <div className="py-6 bg-white dark:bg-gray-900">
        <div className="container mx-auto">
          <div className="max-w-4xl mx-auto">
            <img 
              src={comparison.imageUrl} 
              alt={comparison.title}
              className="w-full h-56 md:h-80 object-cover rounded-lg mb-6"
            />
            
            <h1 className="text-3xl font-bold mb-4">{comparison.title}</h1>
            <p className="text-gray-600 dark:text-gray-400 mb-8">
              {comparison.description}
            </p>
            
            <div className="prose dark:prose-invert max-w-none mb-8">
              <h2>Comment nous avons sélectionné et testé ces produits</h2>
              <p>
                Pour ce comparatif, nous avons pris en compte plusieurs critères essentiels pour vous aider
                à faire le meilleur choix. Notre sélection est basée sur une analyse approfondie des 
                caractéristiques techniques, des performances réelles en utilisation quotidienne, et du 
                rapport qualité-prix de chaque produit.
              </p>
              
              <h3>Nos critères d'évaluation</h3>
              <ul>
                <li><strong>Performance</strong> : nous avons testé la rapidité et l'efficacité de chaque produit.</li>
                <li><strong>Autonomie</strong> : la durée de vie de la batterie est un critère essentiel.</li>
                <li><strong>Rapport qualité-prix</strong> : nous comparons le prix aux fonctionnalités offertes.</li>
                <li><strong>Design et ergonomie</strong> : l'esthétique et la facilité d'utilisation sont prises en compte.</li>
                <li><strong>Qualité de fabrication</strong> : nous évaluons la durabilité et la robustesse.</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <div className="py-8 bg-gray-50 dark:bg-gray-800">
        {comparison.products.length > 0 ? (
          <ComparisonTable 
            title={comparison.title}
            description={comparison.description}
            products={comparison.products}
          />
        ) : (
          <div className="container mx-auto text-center py-16">
            <h3 className="text-xl font-bold mb-2">Aucun produit à comparer</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Ce comparatif ne contient actuellement aucun produit à comparer.
            </p>
          </div>
        )}
      </div>

      <div className="py-8 bg-white dark:bg-gray-900">
        <div className="container mx-auto">
          <div className="max-w-4xl mx-auto">
            <div className="prose dark:prose-invert max-w-none">
              <h2>Notre analyse et recommandations</h2>
              <p>
                Après avoir minutieusement testé et comparé ces produits, nous pouvons vous proposer
                des recommandations adaptées à différents besoins et budgets.
              </p>
              
              <h3>Meilleur choix global</h3>
              <p>
                Si vous recherchez le meilleur produit toutes catégories confondues, nous recommandons 
                le modèle qui offre le meilleur équilibre entre performances, qualité et prix.
              </p>
              
              <h3>Meilleur rapport qualité-prix</h3>
              <p>
                Pour les utilisateurs soucieux de leur budget, certains modèles offrent des fonctionnalités
                très intéressantes à un prix plus abordable.
              </p>
              
              <h3>Pour les utilisateurs exigeants</h3>
              <p>
                Si vous êtes prêt à investir davantage pour obtenir les meilleures performances possibles,
                le haut de gamme vous offrira une expérience premium.
              </p>
              
              <h2>Conclusion</h2>
              <p>
                Chaque produit de ce comparatif présente ses propres forces et faiblesses. Votre choix
                final dépendra principalement de vos besoins spécifiques, de votre budget et de vos préférences
                personnelles. N'hésitez pas à consulter les fiches détaillées de chaque produit pour en savoir plus.
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
