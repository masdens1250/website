import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Product, ProductPrice, Retailer, Review, ReviewCriteria } from "@shared/schema";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import ReviewCard from "@/components/product/review-card";
import { ChevronRight, ShoppingCart, Star } from "lucide-react";
import { formatPrice } from "@/lib/utils";

interface DetailedReview extends Review {
  criteria: ReviewCriteria[];
}

interface DetailedProductReviews {
  product: Product & { specifications: any };
  reviews: DetailedReview[];
}

export default function ProductPage() {
  const [, params] = useRoute("/product/:slug");
  const slug = params?.slug;
  const [activeTab, setActiveTab] = useState("overview");
  
  const { data: productWithReviews, isLoading: isLoadingProduct } = useQuery<DetailedProductReviews>({
    queryKey: [`/api/products/${slug}/detailed-reviews`],
    enabled: !!slug,
  });
  
  const { data: retailers } = useQuery<Retailer[]>({
    queryKey: ['/api/retailers'],
    enabled: !!productWithReviews,
  });
  
  const { data: productPrices } = useQuery<ProductPrice[]>({
    queryKey: [`/api/products/${productWithReviews?.product.id}/prices`],
    enabled: !!productWithReviews?.product.id,
  });
  
  // Set the document title based on the product name
  useEffect(() => {
    if (productWithReviews) {
      document.title = `${productWithReviews.product.name} - Boutiquez`;
    }
  }, [productWithReviews]);
  
  if (isLoadingProduct) {
    return (
      <div className="container mx-auto py-8">
        <div className="md:flex md:space-x-8">
          <div className="md:w-2/5 mb-6 md:mb-0">
            <Skeleton className="w-full h-80 rounded-lg" />
          </div>
          <div className="md:w-3/5">
            <Skeleton className="h-8 w-3/4 mb-4" />
            <Skeleton className="h-4 w-1/4 mb-6" />
            <Skeleton className="h-6 w-1/3 mb-6" />
            <Skeleton className="h-4 w-full mb-2" />
            <Skeleton className="h-4 w-full mb-2" />
            <Skeleton className="h-4 w-3/4 mb-6" />
            <div className="space-y-4">
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  if (!productWithReviews) {
    return (
      <div className="container mx-auto py-16 text-center">
        <h1 className="text-2xl font-bold mb-4">Produit non trouvé</h1>
        <p className="text-gray-600 dark:text-gray-400 mb-6">
          Nous n'avons pas pu trouver le produit demandé.
        </p>
      </div>
    );
  }
  
  const { product, reviews } = productWithReviews;
  
  // Calculate average rating
  const avgRating = product.rating / 100;
  
  // Get prices with retailer info
  const pricesWithRetailer = productPrices?.map(price => {
    const retailer = retailers?.find(r => r.id === price.retailerId);
    return { ...price, retailer };
  }).sort((a, b) => a.price - b.price);
  
  // Get best price
  const bestPrice = pricesWithRetailer && pricesWithRetailer.length > 0 ? pricesWithRetailer[0] : null;
  
  return (
    <>
      <div className="bg-gray-100 dark:bg-gray-800 py-6">
        <div className="container mx-auto">
          <div className="flex items-center text-sm">
            <a href="/" className="text-gray-500 dark:text-gray-400 hover:text-primary dark:hover:text-primary">
              Accueil
            </a>
            <ChevronRight className="h-4 w-4 mx-1 text-gray-400" />
            <a href={`/category/${product.categoryId}`} className="text-gray-500 dark:text-gray-400 hover:text-primary dark:hover:text-primary">
              Catégorie
            </a>
            <ChevronRight className="h-4 w-4 mx-1 text-gray-400" />
            <span className="text-gray-900 dark:text-white font-medium">{product.name}</span>
          </div>
        </div>
      </div>
      
      <div className="container mx-auto py-8">
        <div className="md:flex md:space-x-8">
          <div className="md:w-2/5 mb-6 md:mb-0">
            <img 
              src={product.imageUrl} 
              alt={product.name} 
              className="w-full h-auto rounded-lg"
            />
          </div>
          
          <div className="md:w-3/5">
            <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
            
            <div className="flex items-center mb-4">
              <div className="flex items-center mr-2">
                <Star className="h-5 w-5 text-yellow-400 fill-yellow-400" />
                <span className="ml-1 font-medium">{avgRating.toFixed(1)}</span>
              </div>
              <span className="text-gray-500 dark:text-gray-400">
                {reviews.length} avis
              </span>
            </div>
            
            <div className="text-2xl font-bold text-primary dark:text-primary mb-6">
              {formatPrice(product.price)}
            </div>
            
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              {product.description}
            </p>
            
            <div className="space-y-4 mb-8">
              {bestPrice && (
                <a 
                  href={bestPrice.affiliateUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full"
                >
                  <Button className="w-full flex items-center justify-center gap-2">
                    <ShoppingCart className="h-5 w-5" />
                    Acheter au meilleur prix
                    {bestPrice.retailer && (
                      <span className="ml-2">sur {bestPrice.retailer.name}</span>
                    )}
                  </Button>
                </a>
              )}
              
              <div className="grid grid-cols-2 gap-4">
                {pricesWithRetailer?.slice(1).map(price => (
                  <a 
                    key={price.id}
                    href={price.affiliateUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block w-full"
                  >
                    <Button variant="outline" className="w-full">
                      {price.retailer?.name} - {formatPrice(price.price)}
                    </Button>
                  </a>
                ))}
              </div>
            </div>
            
            <div className="bg-gray-100 dark:bg-gray-800 p-4 rounded-lg mb-6">
              <h3 className="font-semibold mb-2">Points forts</h3>
              <ul className="list-disc list-inside text-gray-600 dark:text-gray-400 space-y-1">
                <li>Excellente performance au quotidien</li>
                <li>Qualité de fabrication premium</li>
                <li>Bon rapport qualité-prix</li>
                <li>Nombreuses fonctionnalités avancées</li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="mt-12">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="w-full justify-start border-b rounded-none">
              <TabsTrigger value="overview">Aperçu</TabsTrigger>
              <TabsTrigger value="specs">Caractéristiques</TabsTrigger>
              <TabsTrigger value="reviews">Avis ({reviews.length})</TabsTrigger>
            </TabsList>
            
            <TabsContent value="overview" className="pt-6">
              <div className="prose dark:prose-invert max-w-none">
                <h2>À propos du {product.name}</h2>
                <p>
                  {product.description}
                </p>
                
                <h3>Notre avis</h3>
                <p>
                  Le {product.name} est un excellent choix pour ceux qui recherchent un produit fiable 
                  et performant. Sa conception soignée et ses fonctionnalités avancées en font un modèle 
                  particulièrement intéressant dans sa catégorie de prix.
                </p>
                
                <h3>Les plus</h3>
                <ul>
                  <li>Design élégant et finitions de qualité</li>
                  <li>Excellentes performances dans toutes les conditions</li>
                  <li>Interface intuitive et agréable à utiliser</li>
                  <li>Bon rapport qualité-prix</li>
                </ul>
                
                <h3>Les moins</h3>
                <ul>
                  <li>Quelques fonctionnalités avancées pourraient être améliorées</li>
                  <li>Prix légèrement plus élevé que certains concurrents</li>
                </ul>
              </div>
            </TabsContent>
            
            <TabsContent value="specs" className="pt-6">
              <div className="bg-white dark:bg-gray-900 rounded-lg shadow overflow-hidden">
                <div className="border-b border-gray-200 dark:border-gray-700 px-4 py-3 bg-gray-50 dark:bg-gray-800">
                  <h3 className="text-lg font-semibold">Caractéristiques techniques</h3>
                </div>
                
                <div className="divide-y divide-gray-200 dark:divide-gray-700">
                  {Object.entries(product.specifications).map(([key, value]) => (
                    <div key={key} className="px-4 py-3 flex">
                      <div className="w-1/3 font-medium capitalize">
                        {key === 'screen' ? 'Écran' : 
                         key === 'battery' ? 'Batterie' : 
                         key === 'camera' ? 'Appareil photo' : 
                         key === 'processor' ? 'Processeur' :
                         key === 'memory' ? 'Mémoire' :
                         key === 'storage' ? 'Stockage' : key}
                      </div>
                      <div className="w-2/3 text-gray-600 dark:text-gray-400">{value}</div>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="reviews" className="pt-6">
              <div className="mb-8">
                <h3 className="text-lg font-semibold mb-4">Avis des utilisateurs</h3>
                
                <div className="flex items-center mb-6">
                  <div className="flex items-center mr-4">
                    <div className="text-4xl font-bold mr-2">{avgRating.toFixed(1)}</div>
                    <div className="flex flex-col">
                      <div className="rating-stars text-xl">
                        {[...Array(5)].map((_, i) => (
                          <span key={i} className={i < Math.round(avgRating) ? "text-yellow-400" : "text-gray-300"}>★</span>
                        ))}
                      </div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">
                        {reviews.length} avis
                      </div>
                    </div>
                  </div>
                </div>
                
                {reviews.length > 0 ? (
                  <div className="space-y-6">
                    {reviews.map((review) => (
                      <ReviewCard 
                        key={review.id} 
                        review={review} 
                        criteria={review.criteria}
                        product={product}
                        showProduct={false}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <h4 className="text-lg font-semibold mb-2">Aucun avis pour le moment</h4>
                    <p className="text-gray-600 dark:text-gray-400">
                      Soyez le premier à donner votre avis sur ce produit !
                    </p>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </>
  );
}
