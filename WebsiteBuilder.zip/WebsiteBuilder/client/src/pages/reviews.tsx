import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Review, Product, ReviewCriteria } from "@shared/schema";
import ReviewCard from "@/components/product/review-card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function ReviewsPage() {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  
  // Set the document title
  useEffect(() => {
    document.title = "Avis produits - Boutiquez";
  }, []);
  
  const { data: reviews, isLoading: isLoadingReviews } = useQuery<Review[]>({
    queryKey: ["/api/reviews"],
  });
  
  const { data: products, isLoading: isLoadingProducts } = useQuery<Product[]>({
    queryKey: ["/api/products"],
    enabled: !isLoadingReviews && !!reviews,
  });
  
  const { data: categories } = useQuery({
    queryKey: ["/api/categories"],
  });
  
  // Fetch review criteria for all reviews
  const criteriaQueries = reviews?.map(review => 
    useQuery<ReviewCriteria[]>({
      queryKey: [`/api/reviews/${review.id}/criteria`],
      enabled: !isLoadingReviews && !!reviews,
    })
  ) || [];
  
  const isLoading = isLoadingReviews || isLoadingProducts || criteriaQueries.some(q => q.isLoading);
  
  const createCombinedReviewData = () => {
    if (!reviews || !products) return [];
    
    return reviews.map((review, index) => {
      const product = products.find(p => p.id === review.productId);
      const criteria = criteriaQueries[index].data || [];
      
      if (!product) return null;
      
      return {
        review,
        product,
        criteria
      };
    }).filter(item => !!item);
  };
  
  const combinedData = createCombinedReviewData();
  
  // Filter reviews by category if a category is selected
  const filteredReviews = selectedCategory === "all" 
    ? combinedData 
    : combinedData.filter(item => item?.product.categoryId.toString() === selectedCategory);
  
  return (
    <>
      <div className="bg-gray-100 dark:bg-gray-800 py-12">
        <div className="container mx-auto">
          <h1 className="text-3xl md:text-4xl font-bold mb-4 text-center">Avis produits</h1>
          <p className="text-gray-600 dark:text-gray-300 text-center max-w-2xl mx-auto">
            Découvrez les avis détaillés de nos utilisateurs sur les derniers produits testés.
            Des évaluations honnêtes pour vous aider à faire le bon choix.
          </p>
        </div>
      </div>
      
      <div className="container mx-auto py-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8">
          <h2 className="text-2xl font-bold mb-4 md:mb-0">Tous les avis</h2>
          
          <div className="w-full md:w-64">
            <Select
              value={selectedCategory}
              onValueChange={setSelectedCategory}
              disabled={isLoading}
            >
              <SelectTrigger>
                <SelectValue placeholder="Filtrer par catégorie" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toutes les catégories</SelectItem>
                {categories?.map(category => (
                  <SelectItem key={category.id} value={category.id.toString()}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="bg-white dark:bg-gray-900 rounded-lg shadow overflow-hidden animate-pulse flex flex-col">
                <div className="p-5 flex-grow">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-gray-200 dark:bg-gray-700 rounded-full"></div>
                      <div className="ml-3">
                        <div className="h-4 w-20 bg-gray-200 dark:bg-gray-700 rounded"></div>
                        <div className="h-3 w-32 bg-gray-200 dark:bg-gray-700 rounded mt-1"></div>
                      </div>
                    </div>
                    <div className="h-4 w-16 bg-gray-200 dark:bg-gray-700 rounded"></div>
                  </div>
                  
                  <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-3/4 mb-4"></div>
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-full mb-2"></div>
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-full mb-4"></div>
                </div>
                
                <div className="px-5 py-3 bg-gray-50 dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-gray-200 dark:bg-gray-700 rounded-lg mr-3"></div>
                    <div>
                      <div className="h-4 w-28 bg-gray-200 dark:bg-gray-700 rounded"></div>
                      <div className="h-3 w-16 bg-gray-200 dark:bg-gray-700 rounded mt-1"></div>
                    </div>
                  </div>
                  <div className="h-4 w-28 bg-gray-200 dark:bg-gray-700 rounded"></div>
                </div>
              </div>
            ))}
          </div>
        ) : filteredReviews.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredReviews.map(item => item && (
              <ReviewCard 
                key={item.review.id} 
                review={item.review} 
                criteria={item.criteria}
                product={item.product}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 bg-white dark:bg-gray-800 rounded-lg shadow">
            <h3 className="text-xl font-bold mb-2">Aucun avis trouvé</h3>
            <p className="text-gray-600 dark:text-gray-400">
              {selectedCategory === "all" 
                ? "Aucun avis n'est disponible pour le moment."
                : "Aucun avis n'est disponible pour cette catégorie."}
            </p>
          </div>
        )}
      </div>
    </>
  );
}
