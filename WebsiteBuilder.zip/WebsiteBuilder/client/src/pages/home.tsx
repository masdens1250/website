import HeroSection from "@/components/sections/hero-section";
import CategoriesSection from "@/components/sections/categories-section";
import FeaturedComparisonSection from "@/components/sections/featured-comparison-section";
import DetailedComparisonSection from "@/components/sections/detailed-comparison-section";
import LatestReviewsSection from "@/components/sections/latest-reviews-section";
import NewsletterSection from "@/components/sections/newsletter-section";

export default function Home() {
  return (
    <>
      <HeroSection />
      <CategoriesSection />
      <FeaturedComparisonSection />
      <DetailedComparisonSection />
      <LatestReviewsSection />
      <NewsletterSection />
    </>
  );
}
