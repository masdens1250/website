import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Category, Product } from "@shared/schema";
import ProductCard from "@/components/product/product-card";
import { Skeleton } from "@/components/ui/skeleton";
import { ChevronRight } from "lucide-react";

export default function CategoryPage() {
  const [, params] = useRoute("/category/:slug");
  const slug = params?.slug;

  const { data: category, isLoading: isLoadingCategory } = useQuery<Category>({
    queryKey: [`/api/categories/${slug}`],
    enabled: !!slug,
  });

  const { data: products, isLoading: isLoadingProducts } = useQuery<Product[]>({
    queryKey: [`/api/categories/${category?.id}/products`],
    enabled: !!category?.id,
  });

  // Set the document title based on the category name
  useEffect(() => {
    if (category) {
      document.title = `${category.name} - Boutiquez`;
    }
  }, [category]);

  if (isLoadingCategory) {
    return (
      <div className="container mx-auto py-8">
        <div className="animate-pulse mb-8">
          <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded-md w-1/3 mb-4"></div>
          <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded-md w-2/3"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, index) => (
            <div key={index} className="bg-white dark:bg-gray-900 rounded-lg shadow overflow-hidden">
              <Skeleton className="w-full h-48" />
              <div className="p-5">
                <Skeleton className="h-6 w-3/4 mb-2" />
                <Skeleton className="h-4 w-1/4 mb-4" />
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-2/3 mb-4" />
                <div className="flex items-center justify-between">
                  <Skeleton className="h-6 w-1/4" />
                  <Skeleton className="h-4 w-1/4" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (!category) {
    return (
      <div className="container mx-auto py-16 text-center">
        <h1 className="text-2xl font-bold mb-4">Catégorie non trouvée</h1>
        <p className="text-gray-600 dark:text-gray-400 mb-6">
          Nous n'avons pas pu trouver la catégorie demandée.
        </p>
      </div>
    );
  }

  return (
    <>
      <div className="bg-gray-100 dark:bg-gray-800 py-6">
        <div className="container mx-auto">
          <div className="flex items-center text-sm">
            <a href="/" className="text-gray-500 dark:text-gray-400 hover:text-primary dark:hover:text-primary">
              Accueil
            </a>
            <ChevronRight className="h-4 w-4 mx-1 text-gray-400" />
            <span className="text-gray-900 dark:text-white font-medium">{category.name}</span>
          </div>
        </div>
      </div>

      <div className="container mx-auto py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-4">{category.name}</h1>
          <p className="text-gray-600 dark:text-gray-400 max-w-3xl">
            Découvrez notre sélection des meilleurs produits dans la catégorie {category.name}. 
            Comparez les caractéristiques et les prix pour faire le meilleur choix.
          </p>
        </div>

        {isLoadingProducts ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, index) => (
              <div key={index} className="bg-white dark:bg-gray-900 rounded-lg shadow overflow-hidden">
                <Skeleton className="w-full h-48" />
                <div className="p-5">
                  <Skeleton className="h-6 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-1/4 mb-4" />
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-2/3 mb-4" />
                  <div className="flex items-center justify-between">
                    <Skeleton className="h-6 w-1/4" />
                    <Skeleton className="h-4 w-1/4" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : products && products.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <div className={`category-icon category-icon-${category.colorClass} mx-auto mb-4`}>
              <i className={`fas ${category.icon} text-2xl`}></i>
            </div>
            <h3 className="text-xl font-bold mb-2">Aucun produit disponible</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Nous n'avons pas encore de produits dans cette catégorie.
              Revenez bientôt pour découvrir notre sélection !
            </p>
          </div>
        )}
      </div>
    </>
  );
}
